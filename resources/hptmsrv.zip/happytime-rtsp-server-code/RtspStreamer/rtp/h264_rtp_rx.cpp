/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "rtp.h"
#include "h264_rtp_rx.h"


/***********************************************************************/

BOOL h264_data_rx(H264RXI * p_rxi, uint8 * p_data, int len)
{
	uint8 * headerStart = p_data;
	uint32  packetSize = len;
	uint32  numBytesToSkip;
	uint8 	fCurPacketNALUnitType;	
	BOOL 	fCurrentPacketBeginsFrame = FALSE;
	BOOL 	fCurrentPacketCompletesFrame = FALSE;

	// Check the 'nal_unit_type' for special 'aggregation' or 'fragmentation' packets
	if (packetSize < 1)
	{
		return FALSE;
	}
	
	fCurPacketNALUnitType = (headerStart[0] & 0x1F);
		
	switch (fCurPacketNALUnitType) 
	{
	case 24:  					// STAP-A
		numBytesToSkip = 1; 	// discard the type byte
		break;
		
	case 25: case 26: case 27:  // STAP-B, MTAP16, or MTAP24
		numBytesToSkip = 3; 	// discard the type byte, and the initial DON
		break;
		
	case 28: case 29: 			// FU-A or FU-B
	{ 
	    // For these NALUs, the first two bytes are the FU indicator and the FU header.
	    // If the start bit is set, we reconstruct the original NAL header into byte 1
	    
	    if (packetSize < 2) 
	    {
	    	return FALSE;
	    }
	    
	    uint8 startBit = headerStart[1] & 0x80;
	    uint8 endBit = headerStart[1] & 0x40;
	    if (startBit) 
	    {
			fCurrentPacketBeginsFrame = TRUE;

			headerStart[1] = (headerStart[0] & 0xE0) | (headerStart[1] & 0x1F);
			numBytesToSkip = 1;
	    } 
	    else 
	    {
			// The start bit is not set, so we skip both the FU indicator and header:
			fCurrentPacketBeginsFrame = FALSE;
			numBytesToSkip = 2;
	    }
	    
		fCurrentPacketCompletesFrame = (endBit != 0);
		break;
	}
	
	default: 
		// This packet contains one complete NAL unit:
		fCurrentPacketBeginsFrame = fCurrentPacketCompletesFrame = TRUE;
		numBytesToSkip = 0;
		break;
	}

	// save the H264 parameter sets
		
	if (fCurPacketNALUnitType == H264_NAL_SPS && p_rxi->param_sets.sps_len == 0)
	{
		if (len <= sizeof(p_rxi->param_sets.sps) - 4)
		{
			int offset = 0;
			
			if (p_data[0] == 0 && p_data[1] == 0 && p_data[2] == 0 && p_data[3] == 1)
			{
			}
			else
			{
				p_rxi->param_sets.sps[0] = 0;
				p_rxi->param_sets.sps[1] = 0;
				p_rxi->param_sets.sps[2] = 0;
				p_rxi->param_sets.sps[3] = 1;

				offset = 4;
			}
			
			memcpy(p_rxi->param_sets.sps+offset, p_data, len);
			p_rxi->param_sets.sps_len = len+offset;
		}
	}
	else if (fCurPacketNALUnitType == H264_NAL_PPS && p_rxi->param_sets.pps_len == 0)
	{
		if (len <= sizeof(p_rxi->param_sets.pps) - 4)
		{
			int offset = 0;
			
			if (p_data[0] == 0 && p_data[1] == 0 && p_data[2] == 0 && p_data[3] == 1)
			{
			}
			else
			{
				p_rxi->param_sets.pps[0] = 0;
				p_rxi->param_sets.pps[1] = 0;
				p_rxi->param_sets.pps[2] = 0;
				p_rxi->param_sets.pps[3] = 1;

				offset = 4;
			}
			
			memcpy(p_rxi->param_sets.pps+offset, p_data, len);
			p_rxi->param_sets.pps_len = len+offset;
		}
	}
		
	if (fCurrentPacketBeginsFrame)
	{
		p_rxi->d_offset = 0;
	}

  	if ((p_rxi->d_offset + 4 + packetSize - numBytesToSkip) >= RTP_MAX_VIDEO_BUFF)
	{
		log_print(LOG_ERR, "%s, fragment packet too big %d!!!", __FUNCTION__, p_rxi->d_offset + 4 + packetSize - numBytesToSkip);
		return FALSE;
	}
	
	memcpy(p_rxi->p_buf + p_rxi->d_offset + 4, headerStart + numBytesToSkip, packetSize - numBytesToSkip);
	p_rxi->d_offset += packetSize - numBytesToSkip;

	if (fCurrentPacketCompletesFrame)
	{
		p_rxi->p_buf[0] = 0;
		p_rxi->p_buf[1] = 0;
		p_rxi->p_buf[2] = 0;
		p_rxi->p_buf[3] = 1;

		if (p_rxi->pkt_func)
  		{
  			p_rxi->pkt_func(p_rxi->p_buf, p_rxi->d_offset + 4, p_rxi->rtprxi.prev_ts, p_rxi->rtprxi.prev_seq, p_rxi->user_data);
  		}

		p_rxi->d_offset = 0;
	} 

	return TRUE;
}

BOOL h264_rtp_rx(H264RXI * p_rxi, uint8 * p_data, int len)
{
	if (p_rxi == NULL)
	{
		return FALSE;
	}
	
	if (!rtp_data_rx(&p_rxi->rtprxi, p_data, len))
	{
		return FALSE;
	}

	return h264_data_rx(p_rxi, p_rxi->rtprxi.p_data, p_rxi->rtprxi.len);
}

BOOL h264_rxi_init(H264RXI * p_rxi, VRTPRXCBF cbf, void * p_userdata)
{
	memset(p_rxi, 0, sizeof(H264RXI));

	p_rxi->buf_len = RTP_MAX_VIDEO_BUFF;
	
	p_rxi->p_buf_org = (uint8 *)malloc(p_rxi->buf_len);
	if (p_rxi->p_buf_org == NULL)
	{
		return -1;
    }
    
	p_rxi->p_buf = p_rxi->p_buf_org + 32;
	p_rxi->buf_len -= 32;
	p_rxi->pkt_func = cbf;
    p_rxi->user_data = p_userdata;

	return 0;
}

void h264_rxi_deinit(H264RXI * p_rxi)
{
	if (p_rxi->p_buf_org)
	{
		free(p_rxi->p_buf_org);
    }
    
	memset(p_rxi, 0, sizeof(H264RXI));
}



