/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef RTSP_PROXY_H
#define RTSP_PROXY_H

#include "rtsp_cln.h"
#include "linked_list.h"
#include "hqueue.h"

class CRtspProxy;

typedef struct
{
    char    suffix[100];
    char    url[256];
    char    user[32];
    char    pass[32];
    int     width;
    int     height;
} PROXY_CFG;

typedef struct _RTSP_PROXY
{
    struct _RTSP_PROXY * next;
    
    PROXY_CFG    cfg;
    
    CRtspProxy * proxy;
} RTSP_PROXY;

typedef void (*ProxyDataCB)(uint8 * data, int size, int type, void * pUserdata);

typedef struct
{
	ProxyDataCB pCallback;
	void *      pUserdata;
	BOOL        bFirst;
} ProxyCB;


#ifdef __cplusplus
extern "C" {
#endif

RTSP_PROXY * rtsp_add_proxy(RTSP_PROXY ** p_proxy);
void         rtsp_free_proxies(RTSP_PROXY ** p_proxy);
BOOL         rtsp_init_proxy(RTSP_PROXY * p_proxy);
void         rtsp_init_proxies();
int          rtsp_get_proxy_nums();
RTSP_PROXY * rtsp_proxy_match(const char * suffix);

#ifdef __cplusplus
}
#endif

class CRtspProxy 
{
public:
    CRtspProxy(void);
    ~CRtspProxy(void);

public:
    void    onNotify(int evt);
    void    onAudio(uint8 * pdata, int len, uint32 ts, uint16 seq);
    void    onVideo(uint8 * pdata, int len, uint32 ts, uint16 seq);
    void    notifyHandler();

    BOOL    startRtsp(const char * url, char * user, char * pass);
    
    char *  getVideoAuxSDPLine(int rtp_pt);
    char *  getAudioAuxSDPLine(int rtp_pt);

    void    addCallback(ProxyDataCB pCallback, void * pUserdata);
    void    delCallback(ProxyDataCB pCallback, void * pUserdata);
    
private:
    void    freeRtsp();
    BOOL    restartRtsp();
    void    clearNotify();
    void    dataCallback(uint8 * data, int size, int type);
    BOOL    isCallbackExist(ProxyDataCB pCallback, void * pUserdata);
    char *  getH264AuxSDPLine(int rtp_pt);
    char *  getH265AuxSDPLine(int rtp_pt);
    char *  getMP4AuxSDPLine(int rtp_pt);
    char *  getAACAuxSDPLine(int rtp_pt);
    
public:
    uint32	has_audio	: 1;
	uint32	has_video	: 1;
	uint32	inited      : 1;
	uint32	reserved	: 29;
	
    int     v_codec;	
	int	    a_codec;
	int     a_samplerate;
	int     a_channels;

    char    m_url[500];
    char    m_user[32];
    char    m_pass[32];

	CRtsp * m_rtsp;
	    
    HQUEUE      * m_notifyQueue;
    pthread_t     m_hNotify;
    
	void        * m_pCallbackMutex;
	LINKED_LIST * m_pCallbackList;
};

#endif


