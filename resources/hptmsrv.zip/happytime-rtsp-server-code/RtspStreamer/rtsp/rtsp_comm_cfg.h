
#ifndef COMM_CFG_H
#define COMM_CFG_H

typedef struct
{
    int     codec;                  // video codec, refer media_format.h
    int     width;                  // video width
    int     height;                 // video height
    int     framerate;              // frame rate
} RTSP_V_INFO;

typedef struct
{
    int     codec;                  // audio codec, refer media_format.h
    int     samplerate;             // sample rate
    int     channels;               // channels
} RTSP_A_INFO;

#endif


