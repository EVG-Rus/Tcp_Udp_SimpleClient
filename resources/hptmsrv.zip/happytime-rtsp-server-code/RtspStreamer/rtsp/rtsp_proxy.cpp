/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "rtsp_proxy.h"
#include "rtsp_cfg.h"
#include "media_format.h"

#ifdef PROXY

int rtsp_notify_cb(int evt, void * p_user)
{
    CRtspProxy * p_proxy = (CRtspProxy *) p_user;

    p_proxy->onNotify(evt);
    return 0;
}

int rtsp_audio_cb(uint8 * pdata, int len, uint32 ts, uint16 seq, void *puser)
{
    CRtspProxy * p_proxy = (CRtspProxy *) puser;

    p_proxy->onAudio(pdata, len, ts, seq);
    return 0;
}

int rtsp_video_cb(uint8 * pdata, int len, uint32 ts, uint16 seq, void *puser)
{
    CRtspProxy * p_proxy = (CRtspProxy *) puser;

    p_proxy->onVideo(pdata, len, ts, seq);
    return 0;
}

void * notifyThread(void * argv)
{
    CRtspProxy * p_proxy = (CRtspProxy *) argv;

    p_proxy->notifyHandler();
    return NULL;
}

/*************************************************************/

RTSP_PROXY * rtsp_add_proxy(RTSP_PROXY ** p_proxy)
{
	RTSP_PROXY * p_tmp;
	RTSP_PROXY * p_new_proxy = (RTSP_PROXY *) malloc(sizeof(RTSP_PROXY));
	if (NULL == p_new_proxy)
	{
		return NULL;
	}

	memset(p_new_proxy, 0, sizeof(RTSP_PROXY));

	p_tmp = *p_proxy;
	if (NULL == p_tmp)
	{
		*p_proxy = p_new_proxy;
	}
	else
	{
		while (p_tmp && p_tmp->next)
		{
			p_tmp = p_tmp->next;
		}
		
		p_tmp->next = p_new_proxy;
	}

	return p_new_proxy;
}

void rtsp_free_proxies(RTSP_PROXY ** p_proxy)
{
	RTSP_PROXY * p_next;
	RTSP_PROXY * p_tmp = *p_proxy;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		if (p_tmp->proxy)
		{
		    delete p_tmp->proxy;
		    p_tmp->proxy = NULL;
		}
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_proxy = NULL;
}

BOOL rtsp_init_proxy(RTSP_PROXY * p_proxy)
{
    BOOL ret = FALSE;
    
    p_proxy->proxy = new CRtspProxy;
    if (p_proxy->proxy)
    {
        ret = p_proxy->proxy->startRtsp(p_proxy->cfg.url, p_proxy->cfg.user, p_proxy->cfg.pass);
    }
    else
    {
        log_print(LOG_ERR, "%s, new rtsp proxy failed\r\n", __FUNCTION__);
    }
    
    return ret;
}

void rtsp_init_proxies()
{
    RTSP_PROXY * p_proxy = g_rtsp_cfg.proxy;
    while (p_proxy)
    {
        rtsp_init_proxy(p_proxy);
        
        p_proxy = p_proxy->next;
    }
}

int rtsp_get_proxy_nums()
{
    int nums = 0;
    
    RTSP_PROXY * p_proxy = g_rtsp_cfg.proxy;
    while (p_proxy)
    {
        nums++;
        
        p_proxy = p_proxy->next;
    }

    return nums;
}

RTSP_PROXY * rtsp_proxy_match(const char * suffix)
{
    RTSP_PROXY * p_proxy = g_rtsp_cfg.proxy;
    while (p_proxy)
    {
        if (strcmp(suffix, p_proxy->cfg.suffix) == 0)
        {
            return p_proxy;
        }
        
        p_proxy = p_proxy->next;
    }
    
    return NULL;
}

/*************************************************************/
CRtspProxy::CRtspProxy(void)
: has_audio(0)
, has_video(0)
, inited(0)
, v_codec(VIDEO_CODEC_NONE)
, a_codec(AUDIO_CODEC_NONE)
, m_rtsp(NULL)
, m_notifyQueue(NULL)
, m_hNotify(NULL)
{
    memset(m_url, 0, sizeof(m_url));
    memset(m_user, 0, sizeof(m_user));
    memset(m_pass, 0, sizeof(m_pass));
    
	m_pCallbackMutex = sys_os_create_mutex();
    m_pCallbackList = h_list_create(FALSE);

    m_notifyQueue = hqCreate(10, sizeof(int), HQ_GET_WAIT | HQ_PUT_WAIT);
    m_hNotify = sys_os_create_thread((void *) notifyThread, this);
}

CRtspProxy::~CRtspProxy(void)
{
    freeRtsp();

    int evt = -1;

    hqBufPut(m_notifyQueue, (char *)&evt);

    while (m_hNotify)
    {
        usleep(20*1000);
    }

    hqDelete(m_notifyQueue);

    h_list_free_container(m_pCallbackList);
    
    sys_os_destroy_sig_mutx(m_pCallbackMutex);
}

void CRtspProxy::freeRtsp()
{
    if (m_rtsp)
    {
        // stop rtsp connection
    	m_rtsp->rtsp_stop();
    	m_rtsp->rtsp_close();
	
        delete m_rtsp;
        m_rtsp = NULL;
    }
}

BOOL CRtspProxy::startRtsp(const char * url, char * user, char * pass)
{
    m_rtsp = new CRtsp;
    if (NULL == m_rtsp)
    {
        log_print(LOG_ERR, "%s, new rtsp failed\r\n", __FUNCTION__);
        return FALSE;
    }

    strncpy(m_url, url, sizeof(m_url)-1);
    strncpy(m_user, user, sizeof(m_user)-1);
    strncpy(m_pass, pass, sizeof(m_pass)-1);

    m_rtsp->set_notify_cb(rtsp_notify_cb, this);
    m_rtsp->set_video_cb(rtsp_video_cb);
    m_rtsp->set_audio_cb(rtsp_audio_cb);
    
    return m_rtsp->rtsp_start(url, user, pass);
}

BOOL CRtspProxy::restartRtsp()
{
    freeRtsp();

    m_rtsp = new CRtsp;
    if (NULL == m_rtsp)
    {
        log_print(LOG_ERR, "%s, new rtsp failed\r\n", __FUNCTION__);
        return FALSE;
    }

    m_rtsp->set_notify_cb(rtsp_notify_cb, this);
    m_rtsp->set_video_cb(rtsp_video_cb);
    m_rtsp->set_audio_cb(rtsp_audio_cb);
    
    return m_rtsp->rtsp_start(m_url, m_user, m_pass);
}

void CRtspProxy::onNotify(int evt)
{
	if (evt == RTSP_EVE_CONNSUCC)
	{
        v_codec = m_rtsp->video_codec();
        a_codec = m_rtsp->audio_codec();

        if (v_codec != VIDEO_CODEC_NONE)
        {
            has_video = 1;
        }

        if (a_codec != AUDIO_CODEC_NONE)
        {
            has_audio = 1;
            a_samplerate = m_rtsp->get_audio_samplerate();
            a_channels = m_rtsp->get_audio_channels();
        }
        
        inited = 1;
	}
	
	hqBufPut(m_notifyQueue, (char *)&evt);
}

void CRtspProxy::onVideo(uint8 * pdata, int len, uint32 ts, uint16 seq)
{
	dataCallback(pdata, len, DATA_TYPE_VIDEO);
}

void CRtspProxy::onAudio(uint8 * pdata, int len, uint32 ts, uint16 seq)
{
	dataCallback(pdata, len, DATA_TYPE_AUDIO);
}

void CRtspProxy::clearNotify()
{
	int evt;
	
	while (!hqBufIsEmpty(m_notifyQueue))
	{
		hqBufGet(m_notifyQueue, (char *)&evt);
	}
}

void CRtspProxy::notifyHandler()
{
    int evt;
    
    while (hqBufGet(m_notifyQueue, (char *)&evt))
    {
        log_print(LOG_DBG, "%s, evt = %d\r\n", __FUNCTION__, evt);
        
        if (evt < 0)
        {
            break;
        }

        if (evt == RTSP_EVE_CONNFAIL || evt == RTSP_EVE_NOSIGNAL || 
            evt == RTSP_EVE_NODATA || evt == RTSP_EVE_STOPPED)
    	{
    	    sleep(1);

    	    clearNotify();
    	    
    	    restartRtsp();
    	}
    }
    
    m_hNotify = NULL;
}

BOOL CRtspProxy::isCallbackExist(ProxyDataCB pCallback, void * pUserdata)
{
	BOOL exist = FALSE;
	ProxyCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (ProxyCB *) p_node->p_data;
		if (p_cb->pCallback == pCallback && p_cb->pUserdata == pUserdata)
		{
			exist = TRUE;
			break;
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);
	
	sys_os_mutex_leave(m_pCallbackMutex);

	return exist;
}

void CRtspProxy::addCallback(ProxyDataCB pCallback, void * pUserdata)
{
	if (isCallbackExist(pCallback, pUserdata))
	{
		return;
	}
	
	ProxyCB * p_cb = (ProxyCB *) malloc(sizeof(ProxyCB));

	p_cb->pCallback = pCallback;
	p_cb->pUserdata = pUserdata;
	p_cb->bFirst = TRUE;

	sys_os_mutex_enter(m_pCallbackMutex);
	h_list_add_at_back(m_pCallbackList, p_cb);	
	sys_os_mutex_leave(m_pCallbackMutex);
}

void CRtspProxy::delCallback(ProxyDataCB pCallback, void * pUserdata)
{
	ProxyCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (ProxyCB *) p_node->p_data;
		if (p_cb->pCallback == pCallback && p_cb->pUserdata == pUserdata)
		{		
			free(p_cb);
			
			h_list_remove(m_pCallbackList, p_node);
			break;
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);

	sys_os_mutex_leave(m_pCallbackMutex);
}

void CRtspProxy::dataCallback(uint8 * data, int size, int type)
{
	ProxyCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (ProxyCB *) p_node->p_data;
		if (p_cb->pCallback != NULL)
		{
			if (p_cb->bFirst && type == DATA_TYPE_VIDEO)
			{
				p_cb->bFirst = FALSE;

				if (v_codec == VIDEO_CODEC_H264)
				{
					uint8 sps[1024], pps[1024];
					int sps_len = 0, pps_len = 0;
				
					if (m_rtsp->get_h264_params(sps, &sps_len, pps, &pps_len))
					{
						p_cb->pCallback(sps, sps_len, type, p_cb->pUserdata);
						p_cb->pCallback(pps, pps_len, type, p_cb->pUserdata);
					}
				}
				else if (v_codec == VIDEO_CODEC_H265)
				{
					uint8 vps[1024], sps[1024], pps[1024];
					int vps_len, sps_len = 0, pps_len = 0;
				
					if (m_rtsp->get_h265_params(sps, &sps_len, pps, &pps_len, vps, &vps_len))
					{
						p_cb->pCallback(vps, vps_len, type, p_cb->pUserdata);
						p_cb->pCallback(sps, sps_len, type, p_cb->pUserdata);
						p_cb->pCallback(pps, pps_len, type, p_cb->pUserdata);
					}
				}
			}

			p_cb->pCallback(data, size, type, p_cb->pUserdata);
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);

	sys_os_mutex_leave(m_pCallbackMutex);
}

char * CRtspProxy::getH264AuxSDPLine(int rtp_pt)
{
	char sdp[1024] = {'\0'};

    if (NULL == m_rtsp)
	{
		return NULL;
	}

	if (m_rtsp->get_h264_sdp_desc(sdp, sizeof(sdp)) == FALSE)
	{
	    log_print(LOG_ERR, "%s, get_h264_sdp_desc failed\r\n", __FUNCTION__);
	    return NULL;
	}
	
  	char const* fmtpFmt = "a=fmtp:%d %s";
    	
  	uint32 fmtpFmtSize = strlen(fmtpFmt)
    	+ 3 /* max char len */
    	+ strlen(sdp);
    	
	char* fmtp = new char[fmtpFmtSize+1];
	memset(fmtp, 0, fmtpFmtSize+1);

  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

  	return fmtp;
}

char * CRtspProxy::getH265AuxSDPLine(int rtp_pt)
{
	char sdp[1024] = {'\0'};

    if (NULL == m_rtsp)
	{
		return NULL;
	}

	if (m_rtsp->get_h265_sdp_desc(sdp, sizeof(sdp)) == FALSE)
	{
	    log_print(LOG_ERR, "%s, get_h265_sdp_desc failed\r\n", __FUNCTION__);
	    return NULL;
	}

	char const* fmtpFmt = "a=fmtp:%d %s";
    	
  	uint32 fmtpFmtSize = strlen(fmtpFmt)
    	+ 3 /* max char len */
    	+ strlen(sdp);
    	
	char* fmtp = new char[fmtpFmtSize+1];
	memset(fmtp, 0, fmtpFmtSize+1);

  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

  	return fmtp;
}

char * CRtspProxy::getMP4AuxSDPLine(int rtp_pt)
{
	char sdp[1024] = {'\0'};

    if (NULL == m_rtsp)
	{
		return NULL;
	}

	if (m_rtsp->get_mp4_sdp_desc(sdp, sizeof(sdp)) == FALSE)
	{
	    log_print(LOG_ERR, "%s, get_mp4_sdp_desc failed\r\n", __FUNCTION__);
	    return NULL;
	}

	char const* fmtpFmt = "a=fmtp:%d %s";
    	
  	uint32 fmtpFmtSize = strlen(fmtpFmt)
    	+ 3 /* max char len */
    	+ strlen(sdp);
    	
	char* fmtp = new char[fmtpFmtSize+1];
	memset(fmtp, 0, fmtpFmtSize+1);

  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

  	return fmtp;
}

char * CRtspProxy::getAACAuxSDPLine(int rtp_pt)
{
	char sdp[1024] = {'\0'};

    if (NULL == m_rtsp)
	{
		return NULL;
	}

	if (m_rtsp->get_aac_sdp_desc(sdp, sizeof(sdp)) == FALSE)
	{
	    log_print(LOG_ERR, "%s, get_aac_sdp_desc failed\r\n", __FUNCTION__);
	    return NULL;
	}

	char const* fmtpFmt = "a=fmtp:%d %s";
    	
  	uint32 fmtpFmtSize = strlen(fmtpFmt)
    	+ 3 /* max char len */
    	+ strlen(sdp);
    	
	char* fmtp = new char[fmtpFmtSize+1];
	memset(fmtp, 0, fmtpFmtSize+1);

  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

  	return fmtp;
}

char * CRtspProxy::getVideoAuxSDPLine(int rtp_pt)
{	
	if (v_codec == VIDEO_CODEC_H264)
	{
		return getH264AuxSDPLine(rtp_pt);		
	}
	else if (v_codec == VIDEO_CODEC_H265)
	{
		return getH265AuxSDPLine(rtp_pt);
	}
	else if (v_codec == VIDEO_CODEC_MP4)
	{
		return getMP4AuxSDPLine(rtp_pt);
	}

	return NULL;  	
}

char * CRtspProxy::getAudioAuxSDPLine(int rtp_pt)
{
	if (a_codec == AUDIO_CODEC_AAC)
	{
		return getAACAuxSDPLine(rtp_pt);		
	}

	return NULL;  	
}

#endif // end of PROXY


