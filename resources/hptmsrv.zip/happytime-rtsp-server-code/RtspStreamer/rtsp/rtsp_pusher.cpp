/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "rtsp_pusher.h"
#include "rtsp_cfg.h"
#include "media_format.h"
#include "rtp.h"
#include "media_util.h"
#include "base64.h"


#ifdef PUSHER

/*************************************************************/

RTSP_PUSHER * rtsp_add_pusher(RTSP_PUSHER ** p_pusher)
{
	RTSP_PUSHER * p_tmp;
	RTSP_PUSHER * p_new_pusher = (RTSP_PUSHER *) malloc(sizeof(RTSP_PUSHER));
	if (NULL == p_new_pusher)
	{
		return NULL;
	}

	memset(p_new_pusher, 0, sizeof(RTSP_PUSHER));

	p_tmp = *p_pusher;
	if (NULL == p_tmp)
	{
		*p_pusher = p_new_pusher;
	}
	else
	{
		while (p_tmp && p_tmp->next)
		{
			p_tmp = p_tmp->next;
		}
		
		p_tmp->next = p_new_pusher;
	}

	return p_new_pusher;
}

void rtsp_free_pushers(RTSP_PUSHER ** p_pusher)
{
	RTSP_PUSHER * p_next;
	RTSP_PUSHER * p_tmp = *p_pusher;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		if (p_tmp->pusher)
		{
		   	delete p_tmp->pusher;
		    p_tmp->pusher = NULL;
		}
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_pusher = NULL;
}

BOOL rtsp_init_pusher(RTSP_PUSHER * p_pusher)
{
    BOOL ret = FALSE;

    p_pusher->pusher = new CRtspPusher(&p_pusher->cfg);
    if (NULL == p_pusher->pusher)
    {
        log_print(LOG_ERR, "%s, new rtsp pusher failed\r\n", __FUNCTION__);
    }

    return ret;
}

void rtsp_init_pushers()
{
    RTSP_PUSHER * p_pusher = g_rtsp_cfg.pusher;
    while (p_pusher)
    {
        rtsp_init_pusher(p_pusher);
        
        p_pusher = p_pusher->next;
    }
}

int rtsp_get_pusher_nums()
{
    int nums = 0;
    
    RTSP_PUSHER * p_pusher = g_rtsp_cfg.pusher;
    while (p_pusher)
    {
        nums++;
        
        p_pusher = p_pusher->next;
    }

    return nums;
}

RTSP_PUSHER * rtsp_pusher_match(const char * suffix)
{
    RTSP_PUSHER * p_pusher = g_rtsp_cfg.pusher;
    while (p_pusher)
    {
        if (strcmp(suffix, p_pusher->cfg.suffix) == 0)
        {
            return p_pusher;
        }
        
        p_pusher = p_pusher->next;
    }
    
    return NULL;
}

void * rtsp_pusher_tcp_rx(void * argv)
{
	CRtspPusher * pthis = (CRtspPusher *)argv;

	pthis->tcpRecvThread();

	return NULL;
}

void * rtsp_pusher_udp_rx(void * argv)
{
	CRtspPusher * pthis = (CRtspPusher *)argv;

	pthis->udpRecvThread();

	return NULL;
}

int video_data_rx(uint8 * p_data, int len, uint32 ts, uint32 seq, void * p_userdata)
{
	CRtspPusher * pthis = (CRtspPusher *)p_userdata;

	pthis->videoDataRx(p_data, len);

	return NULL;
}

int audio_data_rx(uint8 * p_data, int len, uint32 ts, uint32 seq, void * p_userdata)
{
	CRtspPusher * pthis = (CRtspPusher *)p_userdata;

	pthis->audioDataRx(p_data, len);

	return NULL;
}


/*************************************************************/
CRtspPusher::CRtspPusher(PUSHER_CFG * pConfig)
: m_pConfig(pConfig)
, m_bInited(FALSE)
, m_bRecving(FALSE)
, m_tidRecv(0)
, m_rua(NULL)
{    
	m_pCallbackMutex = sys_os_create_mutex();
    m_pCallbackList = h_list_create(FALSE);

	m_pRuaMutex = sys_os_create_mutex();
	
	memset(&m_vua, 0, sizeof(m_vua));
	memset(&m_aua, 0, sizeof(m_aua));

	h265_rxi_init(&m_vua.h265rxi, video_data_rx, this);
	aac_rxi_init(&m_aua.aacrxi, audio_data_rx, this);

	m_aua.aacrxi.size_length = 13;
	m_aua.aacrxi.index_length = 3;
	m_aua.aacrxi.index_delta_length = 3;
	
    initPusher();
}

CRtspPusher::~CRtspPusher(void)
{
	m_bRecving = FALSE;

	while (m_tidRecv)
	{
		usleep(10*1000);
	}
	
	if (m_vua.sfd > 0)
	{
		closesocket(m_vua.sfd);
		m_vua.sfd = 0;
	}

	if (m_aua.sfd > 0)
	{
		closesocket(m_aua.sfd);
		m_aua.sfd = 0;
	}

	closeMedia(&m_vua);
	closeMedia(&m_aua);
	
    h_list_free_container(m_pCallbackList);
    
    sys_os_destroy_sig_mutx(m_pCallbackMutex);
    sys_os_destroy_sig_mutx(m_pRuaMutex);
}

void CRtspPusher::initPusher()
{
	if (m_pConfig->transfer.ip == 0)
	{
		m_pConfig->transfer.ip = get_default_if_ip();
	}
	
	if (m_pConfig->has_video)
	{
		if (m_pConfig->transfer.mode != TRANSFER_MODE_RTSP)
		{
			if (m_pConfig->transfer.vport <= 0 || m_pConfig->transfer.vport >= 65535)
			{
				return;
			}
			
			m_vua.sfd = initSocket(m_pConfig->transfer.ip, m_pConfig->transfer.vport, m_pConfig->transfer.mode);
			if (m_vua.sfd <= 0)
			{
				return;
			}
		}
	}
	
	if (m_pConfig->has_audio)
	{
		if (m_pConfig->transfer.mode != TRANSFER_MODE_RTSP)
		{
			if (m_pConfig->transfer.aport <= 0 || m_pConfig->transfer.aport >= 65535)
			{
				return;
			}
			
			m_aua.sfd = initSocket(m_pConfig->transfer.ip, m_pConfig->transfer.aport, m_pConfig->transfer.mode);
			if (m_aua.sfd <= 0)
			{
				return;
			}
		}
	}

	m_bInited = startPusher();
}

int CRtspPusher::initSocket(uint32 ip, int port, int mode)
{
	struct sockaddr_in saddr;
	SOCKET fd = -1;

	if (mode == TRANSFER_MODE_TCP)
	{
		fd = socket(AF_INET, SOCK_STREAM, 0);
	}
	else if (mode == TRANSFER_MODE_UDP)
	{
		fd = socket(AF_INET, SOCK_DGRAM, 0);
	}
	
	if (fd <= 0)
	{
		return -1;
	}

	int len = 1024 * 1024;
	if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, (char*)&len, sizeof(int)))
	{
		log_print(LOG_WARN, "%s, setsockopt SO_SNDBUF error!!!\r\n", __FUNCTION__);
	}
	if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char*)&len, sizeof(int)))
	{
		log_print(LOG_WARN, "%s, setsockopt SO_SNDBUF error!!!\r\n", __FUNCTION__);
	}
		
	memset(&saddr, 0, sizeof(struct sockaddr_in));
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(port);
	saddr.sin_addr.s_addr = ip;

    if (bind(fd, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in)) < 0)
	{
		log_print(LOG_ERR, "%s, bind errno=%d!!!\r\n", __FUNCTION__, errno);
		closesocket(fd);
		return -1;
	}

	if (mode == TRANSFER_MODE_TCP)
	{
	    if (listen(fd, 5) < 0)
		{
			log_print(LOG_ERR, "%s, listen errno=%d!!!\r\n", __FUNCTION__, errno);
			closesocket(fd);
			return -1;
		}
	}

	return fd;
}

void CRtspPusher::reinitMedia()
{
	closeMedia(&m_vua);
	closeMedia(&m_aua);

	h265_rxi_init(&m_vua.h265rxi, video_data_rx, this);
	aac_rxi_init(&m_aua.aacrxi, audio_data_rx, this);

	m_aua.aacrxi.size_length = 13;
	m_aua.aacrxi.index_length = 3;
	m_aua.aacrxi.index_delta_length = 3;
}

BOOL CRtspPusher::startPusher()
{
	m_bRecving = TRUE;

	if (m_pConfig->transfer.mode == TRANSFER_MODE_TCP)
	{
		m_tidRecv = sys_os_create_thread((void *)rtsp_pusher_tcp_rx, this);
	}
	else if (m_pConfig->transfer.mode == TRANSFER_MODE_UDP)
	{
		m_tidRecv = sys_os_create_thread((void *)rtsp_pusher_udp_rx, this);
	}
	
	return TRUE;
}

void CRtspPusher::tcpRecvThread()
{   
    fd_set fdr;
    int max_fd = 0;

	log_print(LOG_DBG, "%s, start\r\n", __FUNCTION__);

	while (m_bRecving)
	{
		FD_ZERO(&fdr);

		if (m_vua.sfd > 0)
		{
			FD_SET(m_vua.sfd, &fdr);			
			max_fd = (m_vua.sfd > max_fd ? m_vua.sfd : max_fd);		
		}		

		if (m_aua.sfd > 0)
		{
			FD_SET(m_aua.sfd, &fdr);
			max_fd = (m_aua.sfd > max_fd ? m_aua.sfd : max_fd);			
		}		

		if (m_vua.mfd > 0)
		{
			FD_SET(m_vua.mfd, &fdr);
			max_fd = (m_vua.mfd > max_fd ? m_vua.mfd : max_fd);		
		}		

		if (m_aua.mfd > 0)
		{
			FD_SET(m_aua.mfd, &fdr);			
			max_fd = (m_aua.mfd > max_fd ? m_aua.mfd : max_fd);			
		}		

		struct timeval tv;
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		
		int sret = select(max_fd+1, &fdr, NULL, NULL, &tv);
		if (sret == 0)
		{
			continue;
		}
		else if (sret < 0)
		{
			log_print(LOG_ERR, "%s, select err[%s], max fd[%d], sret[%d]!!!\r\n", 
				__FUNCTION__, sys_os_get_socket_error(), max_fd, sret);

			usleep(10*1000);				
			continue;
		}

		if (FD_ISSET(m_vua.sfd, &fdr))
		{
			tcpListenRx(&m_vua);
		}

		if (FD_ISSET(m_aua.sfd, &fdr))
		{
			tcpListenRx(&m_aua);
		}
		
		if (FD_ISSET(m_vua.mfd, &fdr))
		{
			if (!tcpDataRx(&m_vua, MEDIA_TYPE_VIDEO))
			{
				closeMedia(&m_vua);
				
				h265_rxi_init(&m_vua.h265rxi, video_data_rx, this);
			}
		}

		if (FD_ISSET(m_aua.mfd, &fdr))
		{
			if (!tcpDataRx(&m_aua, MEDIA_TYPE_AUDIO))
			{
				closeMedia(&m_aua);
				
				aac_rxi_init(&m_aua.aacrxi, audio_data_rx, this);
			}
		}
	}

    m_tidRecv = 0;
    
	log_print(LOG_DBG, "%s, exit\r\n", __FUNCTION__);
}

void CRtspPusher::tcpListenRx(PUA * p_ua)
{
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	socklen_t size = sizeof(struct sockaddr_in);

	int cfd = accept(p_ua->sfd, (struct sockaddr *)&addr, &size);
	if (cfd < 0)
	{
		log_print(LOG_ERR, "%s, accept ret error[%d]!!!\r\n", __FUNCTION__, errno);
		return;
	}
	
	if (p_ua->mfd == 0)
	{
		p_ua->mfd = cfd;
	}
	else
	{
		closesocket(cfd);
	}
}

BOOL CRtspPusher::tcpDataRx(PUA * p_ua, int type)
{
	RILF * pRtPkt = NULL;
	int len = tcpPacketRx(p_ua, &pRtPkt);
	if (len < 0)
	{
		return FALSE;
	}
	
	if (len > 0 && pRtPkt)
	{
		uint8 * p_data = (uint8 *)pRtPkt + sizeof(RILF);
		int rlen = len - sizeof(RILF);

		if (type == MEDIA_TYPE_VIDEO)
		{
			videoRtpRx(p_ua, p_data, rlen);
		}
		else
		{
			audioRtpRx(p_ua, p_data, rlen);
		}
		
		free(pRtPkt);
	}

	return TRUE;
}

BOOL CRtspPusher::videoRtpRx(PUA * p_ua, uint8 * p_rtp, int rlen)
{
	int ret = -1;

	if (m_pConfig->v_info.codec == VIDEO_CODEC_H264)
	{
		ret = h264_rtp_rx(&p_ua->h264rxi, p_rtp, rlen);
	}
	else if (m_pConfig->v_info.codec == VIDEO_CODEC_H265)
	{
		ret = h265_rtp_rx(&p_ua->h265rxi, p_rtp, rlen);
	}
	else if (m_pConfig->v_info.codec == VIDEO_CODEC_MP4)
	{
		ret = mpeg4_rtp_rx(&p_ua->mpeg4rxi, p_rtp, rlen);
	}
	else if (m_pConfig->v_info.codec == VIDEO_CODEC_JPEG)
	{
		ret = mjpeg_rtp_rx(&p_ua->mjpegrxi, p_rtp, rlen);
	}
	else
	{
		log_print(LOG_ERR, "%s, unsupport video codec\r\n", __FUNCTION__, m_pConfig->v_info.codec);
		return FALSE;
	}

	return ret;
}

BOOL CRtspPusher::audioRtpRx(PUA * p_ua, uint8 * p_rtp, int rlen)
{
	int ret = -1;

	if (m_pConfig->a_info.codec == AUDIO_CODEC_G711A || 
		m_pConfig->a_info.codec == AUDIO_CODEC_G711U || 
		m_pConfig->a_info.codec == AUDIO_CODEC_G726 || 
		m_pConfig->a_info.codec == AUDIO_CODEC_G722 || 
		m_pConfig->a_info.codec == AUDIO_CODEC_OPUS)
	{
		ret = pcm_rtp_rx(&p_ua->pcmrxi, p_rtp, rlen);
	}
	else if (m_pConfig->a_info.codec == AUDIO_CODEC_AAC)
	{
		ret = aac_rtp_rx(&p_ua->aacrxi, p_rtp, rlen);
	}
	else
	{
		log_print(LOG_ERR, "%s, unsupport audio codec\r\n", __FUNCTION__, m_pConfig->a_info.codec);
		return FALSE;
	}

	return ret;
}

int CRtspPusher::tcpPacketRx(PUA * p_ua, RILF ** ppRtPkt)
{
	BOOL bRecvFinished = FALSE;

	uint32 offset = p_ua->recv_data_offset;
	if (offset < sizeof(RILF))
	{
		// The header information has not been received
		int len = recv(p_ua->mfd, p_ua->recv_buf + offset, sizeof(RILF) - offset, 0);
		if (len <= 0)
		{
			log_print(LOG_ERR, "%s, recv ret %d, offset=%d\r\n", __FUNCTION__, len, offset);
			return -1;
		}

		p_ua->recv_data_offset += len;

		if (p_ua->recv_data_offset == sizeof(RILF))
		{
			RILF * pNmHdr = (RILF *)p_ua->recv_buf;
			int nMsgTotalLen = ntohs(pNmHdr->rtp_len) + sizeof(RILF);
			if (nMsgTotalLen > MAX_RTP_LEN)
			{
				log_print(LOG_ERR, "%s, len[%d] > %d !!!\r\n", __FUNCTION__, nMsgTotalLen, MAX_RTP_LEN);
				return -1;
			}

			// Allocate dynamic receive buffer 
			p_ua->dyn_recv_buf = (char *)malloc(nMsgTotalLen);
			if (p_ua->dyn_recv_buf == NULL)
			{
				log_print(LOG_ERR, "%s, dyn_recv_buf len = %d memory failed!!!\r\n", __FUNCTION__, nMsgTotalLen);
				return -1;
			}

			// Copy the header information to the dynamic buffer, and the offset remains unchanged.
			memcpy(p_ua->dyn_recv_buf, p_ua->recv_buf, sizeof(RILF));
			
			if (pNmHdr->rtp_len == 0)
			{
				bRecvFinished = TRUE;
			}
		}
		else if (p_ua->recv_data_offset > sizeof(RILF))
		{
			log_print(LOG_ERR, "%s, recv_data_offset[%u],offset[%u],len[%u]!!!\r\n", 
				__FUNCTION__, p_ua->recv_data_offset, offset, len);
		}
	}
	else
	{
		RILF * pNmHdr = (RILF *)p_ua->dyn_recv_buf;
		if (pNmHdr == NULL)
		{
			log_print(LOG_ERR, "%s, recv_data_offset[%u],dyn_recv_buf is null!!!\r\n", __FUNCTION__, p_ua->recv_data_offset);
			return -1;
		}

		uint32 nMsgTotalLen = ntohs(pNmHdr->rtp_len) + sizeof(RILF);
		if(nMsgTotalLen > MAX_RTP_LEN)
		{
			log_print(LOG_ERR, "%s, len[%d] > %d !!!\r\n", __FUNCTION__, nMsgTotalLen, MAX_RTP_LEN);
			return -1;
		}

		if (nMsgTotalLen > p_ua->recv_data_offset)
		{
			int len = recv(p_ua->mfd, p_ua->dyn_recv_buf + p_ua->recv_data_offset, nMsgTotalLen - p_ua->recv_data_offset, 0);
			if (len <= 0)
			{
				log_print(LOG_ERR, "%s, recv ret %d, offset=%d\r\n", __FUNCTION__, len, p_ua->recv_data_offset);
				return -1;
			}

			p_ua->recv_data_offset += len;
		}

		if (p_ua->recv_data_offset >= nMsgTotalLen)
		{
			bRecvFinished = TRUE;
		}	
	}

	if (bRecvFinished == TRUE)
	{
		RILF * pNmHdr = (RILF *)p_ua->dyn_recv_buf;
		int nMsgTotalLen = ntohs(pNmHdr->rtp_len) + sizeof(RILF);

		// A message has been received

		p_ua->recv_data_offset = 0;
		p_ua->dyn_recv_buf = NULL;
		
		*ppRtPkt = pNmHdr;

		return nMsgTotalLen;
	}

	return 0;
}

void CRtspPusher::videoDataRx(uint8 * p_data, int len)
{
#ifdef RTSP_CRYPT
	if (g_rtsp_cfg.crypt)
	{
		rtsp_crypt_data_decrypt(p_data, len);
	}
#endif

	dataCallback(p_data, len, DATA_TYPE_VIDEO);
}

void CRtspPusher::audioDataRx(uint8 * p_data, int len)
{
#ifdef RTSP_CRYPT
	if (g_rtsp_cfg.crypt)
	{
		rtsp_crypt_data_decrypt(p_data, len);
	}
#endif

	dataCallback(p_data, len, DATA_TYPE_AUDIO);
}

void CRtspPusher::udpRecvThread()
{
	fd_set fdr;
    int max_fd = 0;

	log_print(LOG_DBG, "%s, start\r\n", __FUNCTION__);

	while (m_bRecving)
	{
		FD_ZERO(&fdr);

		if (m_vua.sfd > 0)
		{
			FD_SET(m_vua.sfd, &fdr);
			max_fd = (m_vua.sfd > max_fd ? m_vua.sfd : max_fd);	
		}		

		if (m_aua.sfd > 0)
		{
			FD_SET(m_aua.sfd, &fdr);
			max_fd = (m_aua.sfd > max_fd ? m_aua.sfd : max_fd);			
		}		

		struct timeval tv;
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		
		int sret = select(max_fd+1, &fdr, NULL, NULL, &tv);
		if (sret == 0)
		{
			continue;
		}
		else if (sret < 0)
		{
			log_print(LOG_ERR, "%s, select err[%s], max fd[%d], sret[%d]!!!\r\n", 
				__FUNCTION__, sys_os_get_socket_error(), max_fd, sret);

			usleep(10*1000);				
			continue;
		}

		if (FD_ISSET(m_vua.sfd, &fdr))
		{
			if (!udpDataRx(&m_vua, MEDIA_TYPE_VIDEO))
			{
				closeMedia(&m_vua);

				h265_rxi_init(&m_vua.h265rxi, video_data_rx, this);	
			}
			else if (m_rua)
			{
			    sys_os_mutex_enter(m_pRuaMutex);
			    
			    RSUA * p_rua = (RSUA *) m_rua;
			    if (p_rua)
                {
			        p_rua->lats_rx_time = time(NULL);
                }
                
			    sys_os_mutex_leave(m_pRuaMutex);
			}
		}

		if (FD_ISSET(m_aua.sfd, &fdr))
		{
			if (!udpDataRx(&m_aua, MEDIA_TYPE_AUDIO))
			{
				closeMedia(&m_aua);

				aac_rxi_init(&m_aua.aacrxi, audio_data_rx, this);
			}
			else if (m_rua)
			{
			    sys_os_mutex_enter(m_pRuaMutex);
			    
			    RSUA * p_rua = (RSUA *) m_rua;
                if (p_rua)
                {
			        p_rua->lats_rx_time = time(NULL);
                }

			    sys_os_mutex_leave(m_pRuaMutex);
			}
		}
	}

    m_tidRecv = 0;
    
	log_print(LOG_DBG, "%s, exit\r\n", __FUNCTION__);
}

BOOL CRtspPusher::udpDataRx(PUA * p_ua, int type)
{
	char * p_buf = NULL;
	int buf_len = 0;
	char buf_tmp[2048];

	p_buf = buf_tmp + 32;
	buf_len = sizeof(buf_tmp) - 32;

	struct sockaddr_in addr;
	int addr_len = sizeof(struct sockaddr_in);

	if (p_ua->sfd <= 0)
	{
		return FALSE;
	}
	
	int rlen = recvfrom(p_ua->sfd, p_buf, buf_len, 0, (struct sockaddr *)&addr,(socklen_t *)&addr_len);
	if (rlen <= 0)
	{
		log_print(LOG_ERR, "%s, ret %d,err=[%s]!!!\r\n", __FUNCTION__, rlen, sys_os_get_socket_error());
		return FALSE;
	}

	if (type == MEDIA_TYPE_VIDEO)
	{
		videoRtpRx(p_ua, (uint8*)p_buf, rlen);
	}	
	else if(type == MEDIA_TYPE_AUDIO)
	{
		audioRtpRx(p_ua, (uint8*)p_buf, rlen);
	}
	
	return TRUE;
}

void CRtspPusher::closeMedia(PUA * p_ua)
{
	if (p_ua->mfd)
	{
		closesocket(p_ua->mfd);
		p_ua->mfd = 0;
	}

	if (p_ua->dyn_recv_buf)
	{
		free(p_ua->dyn_recv_buf);
		p_ua->dyn_recv_buf = NULL;
	}

	p_ua->recv_data_offset = 0;

	h265_rxi_deinit(&p_ua->h265rxi);
}

BOOL CRtspPusher::isCallbackExist(PusherCallback pCallback, void *pUserdata)
{
	BOOL exist = FALSE;
	PusherCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (PusherCB *) p_node->p_data;
		if (p_cb->pCallback == pCallback && p_cb->pUserdata == pUserdata)
		{
			exist = TRUE;
			break;
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);
	
	sys_os_mutex_leave(m_pCallbackMutex);

	return exist;
}

void CRtspPusher::addCallback(PusherCallback pCallback, void *pUserdata)
{
	if (isCallbackExist(pCallback, pUserdata))
	{
		return;
	}
	
	PusherCB * p_cb = (PusherCB *) malloc(sizeof(PusherCB));

	p_cb->pCallback = pCallback;
	p_cb->pUserdata = pUserdata;
	p_cb->bFirst = TRUE;

	sys_os_mutex_enter(m_pCallbackMutex);
	h_list_add_at_back(m_pCallbackList, p_cb);	
	sys_os_mutex_leave(m_pCallbackMutex);
}

void CRtspPusher::delCallback(PusherCallback pCallback, void * pUserdata)
{
	PusherCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (PusherCB *) p_node->p_data;
		if (p_cb->pCallback == pCallback && p_cb->pUserdata == pUserdata)
		{		
			free(p_cb);
			
			h_list_remove(m_pCallbackList, p_node);
			break;
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);

	sys_os_mutex_leave(m_pCallbackMutex);
}

void CRtspPusher::dataCallback(uint8 * data, int size, int type)
{
	PusherCB * p_cb = NULL;
	LINKED_NODE * p_node = NULL;
	
	sys_os_mutex_enter(m_pCallbackMutex);

	p_node = h_list_lookup_start(m_pCallbackList);
	while (p_node)
	{
		p_cb = (PusherCB *) p_node->p_data;
		if (p_cb->pCallback != NULL)
		{
			if (p_cb->bFirst && type == DATA_TYPE_VIDEO)
			{
				if (m_pConfig->v_info.codec == VIDEO_CODEC_H264 && 
					m_vua.h264rxi.param_sets.sps_len && 
					m_vua.h264rxi.param_sets.pps_len)
				{
					p_cb->pCallback(m_vua.h264rxi.param_sets.sps, m_vua.h264rxi.param_sets.sps_len, type, p_cb->pUserdata);
					p_cb->pCallback(m_vua.h264rxi.param_sets.pps, m_vua.h264rxi.param_sets.pps_len, type, p_cb->pUserdata);
				}
				else if (m_pConfig->v_info.codec == VIDEO_CODEC_H265 && 
					m_vua.h265rxi.param_sets.vps_len && 
					m_vua.h265rxi.param_sets.sps_len && 
					m_vua.h265rxi.param_sets.pps_len)
				{
					p_cb->pCallback(m_vua.h265rxi.param_sets.vps, m_vua.h265rxi.param_sets.vps_len, type, p_cb->pUserdata);
					p_cb->pCallback(m_vua.h265rxi.param_sets.sps, m_vua.h265rxi.param_sets.sps_len, type, p_cb->pUserdata);
					p_cb->pCallback(m_vua.h265rxi.param_sets.pps, m_vua.h265rxi.param_sets.pps_len, type, p_cb->pUserdata);
				}
				
				p_cb->bFirst = FALSE;
			}
			
			p_cb->pCallback(data, size, type, p_cb->pUserdata);
		}
		
		p_node = h_list_lookup_next(m_pCallbackList, p_node);
	}
	h_list_lookup_end(m_pCallbackList);

	sys_os_mutex_leave(m_pCallbackMutex);
}

char * CRtspPusher::getH264AuxSDPLine(int rtp_pt)
{
	if (m_rua)
	{
		char sdp[1024] = {'\0'};
		
		if (!rsua_get_sdp_h264_desc((RSUA *)m_rua, NULL, sdp, sizeof(sdp)))
		{
			log_print(LOG_ERR, "%s, rsua_get_sdp_h264_desc failed\r\n", __FUNCTION__);
			return NULL;
		}

		char const* fmtpFmt = "a=fmtp:%d %s";
    	
	  	uint32 fmtpFmtSize = strlen(fmtpFmt)
	    	+ 3 /* max char len */
	    	+ strlen(sdp);
	    	
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);

	  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

	  	return fmtp;
	}
	else
	{
		uint8 * sps = m_vua.h264rxi.param_sets.sps; uint32 spsSize = m_vua.h264rxi.param_sets.sps_len;
		uint8 * pps = m_vua.h264rxi.param_sets.pps; uint32 ppsSize = m_vua.h264rxi.param_sets.pps_len;
		
		if (spsSize == 0 || ppsSize == 0)
		{
			return NULL;
		}

		// Set up the "a=fmtp:" SDP line for this stream:
		uint8* spsWEB = new uint8[spsSize]; // "WEB" means "Without Emulation Bytes"
		uint32 spsWEBSize = remove_emulation_bytes(spsWEB, spsSize, sps, spsSize);
		if (spsWEBSize < 4) 
		{
			// Bad SPS size => assume our source isn't ready
			delete[] spsWEB;
			return NULL;
		}
		
		uint8 profileLevelId = (spsWEB[1]<<16) | (spsWEB[2]<<8) | spsWEB[3];
		delete[] spsWEB;

		char* sps_base64 = new char[spsSize*2+1];
		char* pps_base64 = new char[ppsSize*2+1];

		base64_encode(sps, spsSize, sps_base64, spsSize*2+1);
		base64_encode(pps, ppsSize, pps_base64, ppsSize*2+1);
		
		char const* fmtpFmt =
			"a=fmtp:%d packetization-mode=1"
			";profile-level-id=%06X"
			";sprop-parameter-sets=%s,%s";
			
		uint32 fmtpFmtSize = strlen(fmtpFmt)
			+ 3 /* max char len */
			+ 6 /* 3 bytes in hex */
			+ strlen(sps_base64) + strlen(pps_base64);
			
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);
		
		sprintf(fmtp, fmtpFmt, rtp_pt, profileLevelId, sps_base64, pps_base64);

		delete[] sps_base64;
		delete[] pps_base64;

		return fmtp;

	}
}

char * CRtspPusher::getH265AuxSDPLine(int rtp_pt)
{
	if (m_rua)
	{
		char sdp[1024] = {'\0'};
		
		if (!rsua_get_sdp_h265_desc((RSUA *)m_rua, NULL, sdp, sizeof(sdp)))
		{
			log_print(LOG_ERR, "%s, rsua_get_sdp_h265_desc failed\r\n", __FUNCTION__);
			return NULL;
		}

		char const* fmtpFmt = "a=fmtp:%d %s";
    	
	  	uint32 fmtpFmtSize = strlen(fmtpFmt)
	    	+ 3 /* max char len */
	    	+ strlen(sdp);
	    	
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);

	  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

	  	return fmtp;
	}
	else
	{
		uint8* vps = m_vua.h265rxi.param_sets.vps; uint32 vpsSize = m_vua.h265rxi.param_sets.vps_len;
		uint8* sps = m_vua.h265rxi.param_sets.sps; uint32 spsSize = m_vua.h265rxi.param_sets.sps_len;
		uint8* pps = m_vua.h265rxi.param_sets.pps; uint32 ppsSize = m_vua.h265rxi.param_sets.pps_len;

		if (NULL == vps || vpsSize == 0 ||
			NULL == sps || spsSize == 0 ||
			NULL == pps || ppsSize == 0)
		{
			return NULL;
		}

		// Set up the "a=fmtp:" SDP line for this stream.
		uint8* vpsWEB = new uint8[vpsSize]; // "WEB" means "Without Emulation Bytes"
		uint32 vpsWEBSize = remove_emulation_bytes(vpsWEB, vpsSize, vps, vpsSize);
		if (vpsWEBSize < 6/*'profile_tier_level' offset*/ + 12/*num 'profile_tier_level' bytes*/)
		{
			// Bad VPS size => assume our source isn't ready
			delete[] vpsWEB;
			return NULL;
		}
		
		uint8 const* profileTierLevelHeaderBytes = &vpsWEB[6];
		uint32 profileSpace  = profileTierLevelHeaderBytes[0]>>6; // general_profile_space
		uint32 profileId = profileTierLevelHeaderBytes[0]&0x1F; 	// general_profile_idc
		uint32 tierFlag = (profileTierLevelHeaderBytes[0]>>5)&0x1;// general_tier_flag
		uint32 levelId = profileTierLevelHeaderBytes[11]; 		// general_level_idc
		uint8 const* interop_constraints = &profileTierLevelHeaderBytes[5];
		char interopConstraintsStr[100];
		sprintf(interopConstraintsStr, "%02X%02X%02X%02X%02X%02X", 
		interop_constraints[0], interop_constraints[1], interop_constraints[2],
		interop_constraints[3], interop_constraints[4], interop_constraints[5]);
		delete[] vpsWEB;

		char* sprop_vps = new char[vpsSize*2+1];
	  	char* sprop_sps = new char[spsSize*2+1];
	  	char* sprop_pps = new char[ppsSize*2+1];

		base64_encode(vps, vpsSize, sprop_vps, vpsSize*2+1);
	  	base64_encode(sps, spsSize, sprop_sps, spsSize*2+1);
		base64_encode(pps, ppsSize, sprop_pps, ppsSize*2+1);

		char const* fmtpFmt =
			"a=fmtp:%d profile-space=%u"
			";profile-id=%u"
			";tier-flag=%u"
			";level-id=%u"
			";interop-constraints=%s"
			";sprop-vps=%s"
			";sprop-sps=%s"
			";sprop-pps=%s";
			
		uint32 fmtpFmtSize = strlen(fmtpFmt)
			+ 3 /* max num chars: rtpPayloadType */ + 20 /* max num chars: profile_space */
			+ 20 /* max num chars: profile_id */
			+ 20 /* max num chars: tier_flag */
			+ 20 /* max num chars: level_id */
			+ strlen(interopConstraintsStr)
			+ strlen(sprop_vps)
			+ strlen(sprop_sps)
			+ strlen(sprop_pps);
			
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);
		
		sprintf(fmtp, fmtpFmt,
		  	rtp_pt, profileSpace,
			profileId,
			tierFlag,
			levelId,
			interopConstraintsStr,
			sprop_vps,
			sprop_sps,
			sprop_pps);

		delete[] sprop_vps;
		delete[] sprop_sps;
		delete[] sprop_pps;

		return fmtp;
	}
}

char * CRtspPusher::getMP4AuxSDPLine(int rtp_pt)
{
	if (m_rua)
	{
		char sdp[1024] = {'\0'};
		
		if (!rsua_get_sdp_mp4_desc((RSUA *)m_rua, NULL, sdp, sizeof(sdp)))
		{
			log_print(LOG_ERR, "%s, rsua_get_sdp_mp4_desc failed\r\n", __FUNCTION__);
			return NULL;
		}

		char const* fmtpFmt = "a=fmtp:%d %s";
    	
	  	uint32 fmtpFmtSize = strlen(fmtpFmt)
	    	+ 3 /* max char len */
	    	+ strlen(sdp);
	    	
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);

	  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

	  	return fmtp;
	}

	return NULL;
}

char * CRtspPusher::getAACAuxSDPLine(int rtp_pt)
{
	if (m_rua)
	{
		char sdp[1024] = {'\0'};
		
		if (!rsua_get_sdp_aac_desc((RSUA *)m_rua, NULL, sdp, sizeof(sdp)))
		{
			log_print(LOG_ERR, "%s, rsua_get_sdp_aac_desc failed\r\n", __FUNCTION__);
			return NULL;
		}

		char const* fmtpFmt = "a=fmtp:%d %s";
    	
	  	uint32 fmtpFmtSize = strlen(fmtpFmt)
	    	+ 3 /* max char len */
	    	+ strlen(sdp);
	    	
		char* fmtp = new char[fmtpFmtSize+1];
		memset(fmtp, 0, fmtpFmtSize+1);

	  	sprintf(fmtp, fmtpFmt, rtp_pt, sdp);

	  	return fmtp;
	}
	
	return NULL;
}

char * CRtspPusher::getVideoAuxSDPLine(int rtp_pt)
{
	int codec = m_pConfig->v_info.codec;
	char * sdp = NULL;

	sys_os_mutex_enter(m_pRuaMutex);
	
	if (m_rua)
	{
		RSUA * p_rua = (RSUA *)m_rua;
		
		codec = p_rua->media_info.v_codec;
	}
	
	if (codec == VIDEO_CODEC_H264)
	{
		sdp = getH264AuxSDPLine(rtp_pt);		
	}
	else if (codec == VIDEO_CODEC_H265)
	{
		sdp = getH265AuxSDPLine(rtp_pt);
	}
	else if (codec == VIDEO_CODEC_MP4)
	{
		sdp = getMP4AuxSDPLine(rtp_pt);
	}

	sys_os_mutex_leave(m_pRuaMutex);
	
	return sdp;  	
}

char * CRtspPusher::getAudioAuxSDPLine(int rtp_pt)
{
	int codec = m_pConfig->a_info.codec;
	char * sdp = NULL;
	
	sys_os_mutex_enter(m_pRuaMutex);
	
	if (m_rua)
	{
		RSUA * p_rua = (RSUA *)m_rua;
		
		codec = p_rua->media_info.a_codec;
	}
	
	if (codec == AUDIO_CODEC_AAC)
	{
		sdp = getAACAuxSDPLine(rtp_pt);		
	}

	sys_os_mutex_leave(m_pRuaMutex);
	
	return sdp;  	
}


/*******************************************************************************/

void CRtspPusher::setRua(void * p_rua) 
{
	if (m_pConfig->transfer.mode != TRANSFER_MODE_RTSP)
	{
		return;
	}
	
	sys_os_mutex_enter(m_pRuaMutex);

	m_rua = p_rua;

	if (NULL == m_rua)
	{
		reinitMedia();
	}
	
	sys_os_mutex_leave(m_pRuaMutex);
}

void CRtspPusher::setAACConfig(int size_length, int index_length, int index_delta_length)
{
	m_aua.aacrxi.size_length = size_length;
	m_aua.aacrxi.index_length = index_length;
	m_aua.aacrxi.index_delta_length = index_delta_length;
}

void CRtspPusher::setMpeg4Config(uint8 * data, int len)
{
	m_vua.mpeg4rxi.hdr_len = len;
	memcpy(m_vua.mpeg4rxi.p_buf, data, len);
}

BOOL CRtspPusher::startUdpRx(int vfd, int afd)
{
	if (m_pConfig->transfer.mode == TRANSFER_MODE_RTSP)
	{
		m_vua.sfd = vfd;
		m_aua.sfd = afd;
	
		m_bRecving = TRUE;
		m_tidRecv = sys_os_create_thread((void *)rtsp_pusher_udp_rx, this);

		return TRUE;
	}

	return FALSE;
}

void CRtspPusher::stopUdpRx()
{
	if (m_pConfig->transfer.mode != TRANSFER_MODE_RTSP)
	{
		return;
	}
	
	m_bRecving = FALSE;

	while (m_tidRecv)
	{
		usleep(10*1000);
	}
	
	reinitMedia();
}

BOOL CRtspPusher::videoRtpRx(uint8 * p_rtp, int rlen)
{
	return videoRtpRx(&m_vua, p_rtp, rlen);
}

BOOL CRtspPusher::audioRtpRx(uint8 * p_rtp, int rlen)
{
	return audioRtpRx(&m_aua, p_rtp, rlen);
}

void CRtspPusher::setVideoInfo(int has_video, int codec)
{
	m_pConfig->has_video = has_video;
	m_pConfig->v_info.codec = codec;
}

void CRtspPusher::setAudioInfo(int has_audio, int codec, int samplerate, int channels)
{
	m_pConfig->has_audio = has_audio;
	m_pConfig->a_info.codec = codec;
	m_pConfig->a_info.samplerate = samplerate;
	m_pConfig->a_info.channels = channels;
}

#endif


