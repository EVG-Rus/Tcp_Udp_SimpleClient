
#include "sys_inc.h"
#include "rtsp_crypt.h"


#ifdef RTSP_CRYPT

void rtsp_crypt_init()
{
}

void rtsp_crypt_uninit()
{
}

BOOL rtsp_crypt_data_decrypt(uint8 * p_data, int len)
{
	return TRUE;
}


#endif // end of RTSP_CRYPT



