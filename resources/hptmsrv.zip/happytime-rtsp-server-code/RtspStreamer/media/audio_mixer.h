/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef _AUDIO_MIXER_H_
#define _AUDIO_MIXER_H_

#include <mmsystem.h>
#include <vector>
#include <string>

using namespace std;

typedef enum
{
    UM_MIXER_COMP_MASTER,
    UM_MIXER_COMP_WAVE,
    UM_MIXER_COMP_LINEIN,
	UM_MIXER_COMP_WAVEIN
} MIXER_COMP_TYPE;

typedef enum
{
    UM_MIXER_CTRL_VOLUME,
    UM_MIXER_CTRL_MUTE,
	UM_MIXER_CTRL_ONOFF,
} MIXER_CTRL_TYPE;


class CAudioMixer
{
public:
    CAudioMixer();
    ~CAudioMixer();

    UINT            GetNumDevs();
    BOOL            GetDevName(UINT nIndex, LPTSTR lpName, int nLen);
    BOOL            OpenDevice(LPCTSTR lpszDevice);
    BOOL            GetMixerControl(short nComponent, short nControl, DWORD * pdwValue);
    BOOL            SetMixerControl(short nComponent, short nControl, DWORD dwValue);
    BOOL            GetMasterVolume(DWORD * pdwValue, BOOL bMute = FALSE);
    BOOL            GetWaveVolume(DWORD * pdwValue, BOOL bMute = FALSE);
    BOOL            GetLineVolume(DWORD * pdwValue, BOOL bMute = FALSE);
    BOOL            SetMasterVolume(DWORD dwValue, BOOL bMute = FALSE);
    BOOL            SetWaveVolume(DWORD dwValue, BOOL bMute = FALSE);
    BOOL            SetLineVolume(DWORD dwValue, BOOL bMute = FALSE);    
    BOOL            SetRecordSource(UINT nIndex);

#ifdef UNICODE
    int             GetRecordSource(vector<wstring> & strNameVec);
    int             GetControlList(DWORD dwComponentType, DWORD dwControlType, vector<wstring> & strNameVec);
#else
    int             GetRecordSource(vector<string> & strNameVec);
    int             GetControlList(DWORD dwComponentType, DWORD dwControlType, vector<string> & strNameVec);
#endif

    BOOL            SetControl(DWORD dwComponentType, DWORD dwControlType, UINT nIndex, BOOL bSelect);

    BOOL            GetMicVolumeRange(int & min, int & max);
    BOOL            GetMicVolume(DWORD & volume);
    BOOL            SetMicVolume(DWORD volume);
    BOOL            SetMicAsRecSrc();
    
private:
    DWORD           ToComponentType(short nComponent);
    DWORD           ToControl(short nControl);
    
private:
    HMIXER          m_hMixer;
};

#endif // _AUDIO_MIXER_H_

