/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "audio_play_win.h"


void CALLBACK waveOutProc(HWAVEOUT hwo, UINT uMsg, DWORD_PTR dwInstance, DWORD_PTR dwParam1, DWORD_PTR dwParam2) 
{ 
	if (dwInstance == NULL)
	{
		return ;
    }
    
	CWAudioPlay * pAudioHandle = (CWAudioPlay *)dwInstance;

    if (uMsg == WOM_DONE)
    {
	    pAudioHandle->waveOutProc();
    }
    else if (uMsg == WOM_CLOSE)
    {
        pAudioHandle->onClose();
    }
    
    return; 
}


CWAudioPlay::CWAudioPlay(int samplerate, int channels) : CAudioPlay(samplerate, channels)
{
	m_hWaveOut				= NULL;
	m_pWaveBlocks			= NULL;	
	m_waveFreeBlockCount	= 0; 
	m_waveCurrentBlock		= 0;

	::InitializeCriticalSection(&m_waveCriticalSection);
}

CWAudioPlay::~CWAudioPlay(void)
{
    stopPlay();

	DeleteCriticalSection(&m_waveCriticalSection);
}

BOOL CWAudioPlay::startPlay()
{
	MMRESULT ret = 0;
	
	m_pWaveBlocks = allocateBlocks(BLOCK_SIZE, BLOCK_COUNT); 
	if (m_pWaveBlocks == NULL)
	{
		goto error;
	}

	WAVEFORMATEX wfx;

	memset(&wfx, 0, sizeof(wfx));
	
	wfx.nChannels = m_nChannels;
	wfx.wBitsPerSample = 16;
	wfx.wFormatTag =  WAVE_FORMAT_PCM;
	wfx.cbSize = 0;
	wfx.nSamplesPerSec = m_nSamplerate;
	wfx.nAvgBytesPerSec = m_nSamplerate * m_nChannels * 2;
	wfx.nBlockAlign = m_nChannels * 2;

    m_waveFreeBlockCount = BLOCK_COUNT; 
	m_waveCurrentBlock = 0; 

	ret = waveOutOpen(0, WAVE_MAPPER, &wfx, 0, 0, WAVE_FORMAT_QUERY);
	if (MMSYSERR_NOERROR != ret) 
	{
		goto error;
	} 

    ret = waveOutOpen(&m_hWaveOut, WAVE_MAPPER, &wfx, (DWORD_PTR)::waveOutProc, (DWORD_PTR)this, CALLBACK_FUNCTION);
	if (MMSYSERR_NOERROR != ret) 
	{ 
		goto error;
	}

	m_bInited = TRUE;
	
	return TRUE;

error:

	if (m_pWaveBlocks) 
	{
		freeBlocks(m_pWaveBlocks);
		m_pWaveBlocks = NULL;
	}

	if (m_hWaveOut)
	{
		waveOutClose(m_hWaveOut); 
		m_hWaveOut = NULL;
	}	

	return FALSE;
}

void CWAudioPlay::stopPlay(void)
{
	if (m_bInited == FALSE)
	{
		return;
    }

	m_bInited = FALSE;
	
	if (m_hWaveOut)
	{
		waveOutReset(m_hWaveOut);
	    waveOutClose(m_hWaveOut); 
	}
}


int CWAudioPlay::setVolume(int volume)
{
    if (volume < 0 || volume > 255 || !m_hWaveOut)
    {
        return -1;
    }

    volume = MAKEWORD(volume, volume);
    
    waveOutSetVolume(m_hWaveOut, volume);

    return 0;
}


int CWAudioPlay::getVolume()
{
    if (!m_hWaveOut)
    {
        return 0;
    }

    DWORD volume = 0;
    
    waveOutGetVolume(m_hWaveOut, &volume);

    volume = LOBYTE(volume);
    
    return volume;
}

	
void CWAudioPlay::playAudio(uint8 * data, int size) 
{ 
	if (!m_bInited || m_pWaveBlocks == NULL)
	{
		return;
	}

	int remain; 
	MMRESULT result;	
    WAVEHDR * current = &m_pWaveBlocks[m_waveCurrentBlock];	
	HWAVEOUT hWaveOut = m_hWaveOut;

    while (size > 0) 
    { 
        if (current->dwFlags & WHDR_PREPARED)  
		{
            result = waveOutUnprepareHeader(hWaveOut, current, sizeof(WAVEHDR)); 
		}
		
        if (size < (int)(BLOCK_SIZE - current->dwUser)) 
        { 
            memcpy(current->lpData + current->dwUser, data, size); 
            current->dwUser += size; 
            break; 
        } 

        remain = BLOCK_SIZE - current->dwUser; 
        memcpy(current->lpData + current->dwUser, data, remain); 
        size -= remain; 
        data += remain; 
        current->dwBufferLength = BLOCK_SIZE; 
        result = waveOutPrepareHeader(hWaveOut, current, sizeof(WAVEHDR)); 
        result = waveOutWrite(hWaveOut, current, sizeof(WAVEHDR)); 

        EnterCriticalSection(&m_waveCriticalSection); 
        m_waveFreeBlockCount--; 
        LeaveCriticalSection(&m_waveCriticalSection); 

		// Wait a free block
        while (!m_waveFreeBlockCount) 
        {
            usleep(10*1000); 
        }
        
		// Point to the next block of data
        m_waveCurrentBlock++; 
        m_waveCurrentBlock %= BLOCK_COUNT; 
        current = &m_pWaveBlocks[m_waveCurrentBlock]; 
        current->dwUser = 0;
    } 
} 

WAVEHDR* CWAudioPlay::allocateBlocks(int size, int count) 
{
	int i; 
    uint8 * buffer; 
    
    WAVEHDR * blocks; 
    SIZE_T totalBufferSize = (size + sizeof(WAVEHDR)) * count; 

    buffer = (uint8 *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T)totalBufferSize);
	if (buffer == NULL)
    { 
        return NULL;
    } 

    blocks = (WAVEHDR *)buffer; 
    buffer += sizeof(WAVEHDR) * count; 
    
    for (i = 0; i < count; i++) 
    { 
        blocks[i].dwBufferLength = size; 
        blocks[i].lpData = (char *)buffer; 
        buffer += size; 
    } 

    return blocks; 
} 


void CWAudioPlay::freeBlocks(WAVEHDR* blockArray) 
{ 
    HeapFree(GetProcessHeap(), 0, blockArray); 
} 

void CWAudioPlay::waveOutProc()
{
    EnterCriticalSection(&m_waveCriticalSection); 
    m_waveFreeBlockCount++; 
    LeaveCriticalSection(&m_waveCriticalSection); 
}

void CWAudioPlay::onClose()
{
    if (m_hWaveOut)
	{	    
        while (m_waveFreeBlockCount < BLOCK_COUNT) 
        {
            usleep(10*1000); 
        }
        
        for (int i = 0; i < m_waveFreeBlockCount; i++) 
        {
            if (m_pWaveBlocks[i].dwFlags & WHDR_PREPARED) 
            {
                waveOutUnprepareHeader(m_hWaveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));  
            }
        } 
	}

	freeBlocks(m_pWaveBlocks); 
	m_pWaveBlocks = NULL;
	
	m_hWaveOut = NULL;	
	
	m_bInited = FALSE;
}



