/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "video_capture_win.h"
#include "media_format.h"
#include "dshow_utils.h"
#include "lock.h"

/***************************************************************************************/

#pragma comment(lib, "strmiids.lib") 


/***************************************************************************************/

static void * videoCaptureThread(void * argv)
{
	CWVideoCapture *capture = (CWVideoCapture *)argv;

	capture->captureThread();

	return NULL;
}

CWVideoCapture::CWVideoCapture(void) : CVideoCapture()
{
	m_pGraphBuilder = NULL;
    m_pSampleGrabberFilter = NULL;
    m_pSampleGrabber = NULL;
    m_pMediaEvent = NULL;
    m_pMediaControl = NULL;
    m_pNullRendererFilter = NULL;
    m_pDeviceFilter = NULL; 

	m_nBuffersize = 0;
	m_pBuffer = NULL;
}

CWVideoCapture::~CWVideoCapture(void)
{
    stopCapture();
}

CVideoCapture * CWVideoCapture::getInstance(int devid)
{
	if (devid < 0 || devid >= MAX_VIDEO_DEV_NUMS)
	{
		return NULL;
	}
	
	if (NULL == m_pInstance[devid])
	{
		sys_os_mutex_enter(m_pInstMutex);

		if (NULL == m_pInstance[devid])
		{
			m_pInstance[devid] = (CVideoCapture *)new CWVideoCapture;
			if (m_pInstance[devid])
			{
				m_pInstance[devid]->m_nRefCnt++;
				m_pInstance[devid]->m_nDevIndex = devid;
			}
		}
		
		sys_os_mutex_leave(m_pInstMutex);
	}
	else
	{
		sys_os_mutex_enter(m_pInstMutex);
		m_pInstance[devid]->m_nRefCnt++;
		sys_os_mutex_leave(m_pInstMutex);
	}

	return m_pInstance[devid];
}

int CWVideoCapture::getDeviceNums()
{
	int count = 0;

	CoInitialize(NULL);
	
	// enumerate all video capture devices
	CComPtr<ICreateDevEnum> pCreateDevEnum;
	HRESULT hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER, IID_ICreateDevEnum, (void**)&pCreateDevEnum);
	if (hr != NOERROR) 
	{
		return count;
	}
	
	CComPtr<IEnumMoniker> pEnumMoniker;
	hr = pCreateDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEnumMoniker, 0);
	if (hr != NOERROR) 
	{
		return count;
	}

	pEnumMoniker->Reset();
	
	IMoniker * pMoniker;
	
	while (S_OK == pEnumMoniker->Next(1, &pMoniker, NULL))
	{
		count++;
		pMoniker->Release();
	}

	pCreateDevEnum = NULL;
	pEnumMoniker = NULL;
	
	return count;
}

BOOL CWVideoCapture::getDeviceFilter(int nCamID, IBaseFilter **pFilter)
{
    if (nCamID < 0)
    {
        return FALSE;
 	}
 	
    // enumerate all video capture devices
    CComPtr<ICreateDevEnum> pCreateDevEnum;
    HRESULT hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER, IID_ICreateDevEnum, (void**)&pCreateDevEnum);
    if (hr != NOERROR)
    {
        return FALSE;
    }

    CComPtr<IEnumMoniker> pEnumMoniker;
    hr = pCreateDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEnumMoniker, 0);
    if (hr != NOERROR) 
    {
        return FALSE;
    }

    pEnumMoniker->Reset();
    
    CComPtr<IMoniker> pMoniker;
    int index = 0;
    BOOL ret = FALSE;
    
    while (S_OK == pEnumMoniker->Next(1, &pMoniker, NULL))
    {
    	if (nCamID == index)
    	{
    		if (S_OK == pMoniker->BindToObject(0, 0, IID_IBaseFilter, (void**)pFilter))
    		{
    			ret = TRUE;
    		}
    		break;
    	}

		index++;
    }

	pEnumMoniker = NULL;
    pCreateDevEnum = NULL;
    
    return ret;
}

BOOL CWVideoCapture::connectFilters()
{
	HRESULT hr;

	CComPtr<IPin> pGrabberInput;
    CComPtr<IPin> pGrabberOutput;
    CComPtr<IPin> pCameraOutput;
    CComPtr<IPin> pNullInputPin;
	
	hr = getOutPin(m_pDeviceFilter, 0, &pCameraOutput);
	if (FAILED(hr)) 
    {
        return FALSE;
    }
	
	hr = getInPin(m_pSampleGrabberFilter, 0, &pGrabberInput);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
	hr = getOutPin(m_pSampleGrabberFilter, 0, &pGrabberOutput);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
	hr = getInPin(m_pNullRendererFilter, 0, &pNullInputPin);
	if (FAILED(hr))
	{
		return FALSE;
	}

    hr = m_pGraphBuilder->Connect(pCameraOutput, pGrabberInput);
    if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pGraphBuilder->Connect(pGrabberOutput, pNullInputPin);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    return TRUE;
}

void CWVideoCapture::freeMediaType(AM_MEDIA_TYPE * p_mt)
{
	if (NULL == p_mt)
	{
		return;
	}
	
	if (p_mt->cbFormat != 0)
	{
		CoTaskMemFree((PVOID)p_mt->pbFormat);
		p_mt->cbFormat = 0;
		p_mt->pbFormat = NULL;
	}
	
	if (p_mt->pUnk != NULL)
	{ 
		p_mt->pUnk->Release();
		p_mt->pUnk = NULL;
	}     
}

BOOL CWVideoCapture::checkMediaType()
{
	AM_MEDIA_TYPE mt;
	
	HRESULT hr = m_pSampleGrabber->GetConnectedMediaType(&mt);    
	if (FAILED(hr))
	{
		return FALSE;
	}

	if (MEDIATYPE_Video != mt.majortype)
	{
		freeMediaType(&mt);
		return FALSE;
	}
	
    VIDEOINFOHEADER * videoHeader;
    
    videoHeader = reinterpret_cast<VIDEOINFOHEADER*>(mt.pbFormat);
    m_nWidth = videoHeader->bmiHeader.biWidth;
    m_nHeight = videoHeader->bmiHeader.biHeight;

	BOOL ret = TRUE;

	if (mt.subtype == MEDIASUBTYPE_YUYV)
	{
		m_nVideoFormat = VIDEO_FMT_YUYV422;
	}
	else if (mt.subtype == MEDIASUBTYPE_IYUV)
	{
		m_nVideoFormat = VIDEO_FMT_YUV420P;
	}
	else if (mt.subtype == MEDIASUBTYPE_YUY2)
	{
		m_nVideoFormat = VIDEO_FMT_YUYV422;
	}
	else if (mt.subtype == MEDIASUBTYPE_YVYU)
	{
		m_nVideoFormat = VIDEO_FMT_YVYU422;
	}
	else if (mt.subtype == MEDIASUBTYPE_UYVY)
	{
		m_nVideoFormat = VIDEO_FMT_UYVY422;
	}
	else if (mt.subtype == MEDIASUBTYPE_NV12)
	{
		m_nVideoFormat = VIDEO_FMT_NV12;
	}
	else if (mt.subtype == MEDIASUBTYPE_RGB24)
	{
		m_nVideoFormat = VIDEO_FMT_RGB24;
	}
	else if (mt.subtype == MEDIASUBTYPE_RGB32)
	{
		m_nVideoFormat = VIDEO_FMT_RGB32;
	}
	else if (mt.subtype == MEDIASUBTYPE_ARGB32)
	{
		m_nVideoFormat = VIDEO_FMT_ARGB;
	}
	else
	{
		ret = FALSE;
	}

	freeMediaType(&mt);

	return TRUE;
}

BOOL CWVideoCapture::initCapture(int codec, int width, int height, int framerate)
{
	HRESULT hr = S_OK;

	CLock lock(m_pMutex);
	
	if (m_bInited)
	{
		return TRUE;
	}

	m_nFramerate = framerate;
	
	CoInitialize(NULL);
	
	// Create the Filter Graph Manager.
    hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC, IID_IGraphBuilder, (void **)&m_pGraphBuilder);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (LPVOID *)&m_pSampleGrabberFilter);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pGraphBuilder->QueryInterface(IID_IMediaControl, (void **) &m_pMediaControl);
    if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pGraphBuilder->QueryInterface(IID_IMediaEvent, (void **) &m_pMediaEvent);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = CoCreateInstance(CLSID_NullRenderer, NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (LPVOID*) &m_pNullRendererFilter);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pGraphBuilder->AddFilter(m_pNullRendererFilter, L"NullRenderer");
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pSampleGrabberFilter->QueryInterface(IID_ISampleGrabber, (void**)&m_pSampleGrabber);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    hr = m_pGraphBuilder->AddFilter(m_pSampleGrabberFilter, L"SampleGrabber");
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    if (FALSE == getDeviceFilter(m_nDevIndex, &m_pDeviceFilter))
    {
    	return FALSE;
    }
    
    hr = m_pGraphBuilder->AddFilter(m_pDeviceFilter, L"Camera");
	if (FAILED(hr))
	{
		return FALSE;
	}
	
    if (FALSE == connectFilters())
    {
    	return FALSE;
    }

	if (FALSE == checkMediaType())
	{
		return FALSE;
	}

    m_pSampleGrabber->SetBufferSamples(TRUE);
    m_pSampleGrabber->SetOneShot(FALSE);

	VideoEncoderParam params;
	memset(&params, 0, sizeof(params));
	
	params.SrcWidth = m_nWidth;
	params.SrcHeight = m_nHeight;
	params.SrcPixFmt = CVideoEncoder::toAVPixelFormat(m_nVideoFormat);
	params.DstCodec = codec;
	params.DstWidth = width ? width : m_nWidth;
	params.DstHeight = height ? height : m_nHeight;
	params.DstFramerate = framerate;
		
	if (m_encoder.init(&params) == FALSE)
	{
		return FALSE;
	}
	
   	m_bInited = TRUE;
   	
	return TRUE;
}

BOOL CWVideoCapture::capture()
{
	long code = 0;
    HRESULT hr;

	if (!m_bInited)
	{
		return FALSE;
	}
	
    hr = m_pMediaControl->Run();
	if (FAILED(hr))
	{
		return FALSE;
	}
    
	long size = 0;
	hr = m_pSampleGrabber->GetCurrentBuffer(&size, NULL);
	if (FAILED(hr))
	{
		return FALSE;
	}
	
	if (size > m_nBuffersize)
	{
		if (m_pBuffer)
		{
			delete[] m_pBuffer;
		}
		
		m_pBuffer = new uint8[size];
		if (NULL == m_pBuffer)
		{
			return FALSE;
		}
		
		m_nBuffersize = size;
	}
	
	hr = m_pSampleGrabber->GetCurrentBuffer(&size, (long *)m_pBuffer);
	if (FAILED(hr))
	{
		return FALSE;
	}

	return m_encoder.encode(m_pBuffer, size);	
}

BOOL CWVideoCapture::startCapture()
{
	CLock lock(m_pMutex);
	
	if (m_hCapture)
	{
		return TRUE;
	}

	m_bCapture = TRUE;
	m_hCapture = sys_os_create_thread((void *)videoCaptureThread, this);

	return (NULL != m_hCapture);
}

void CWVideoCapture::stopCapture()
{
	CLock lock(m_pMutex);
	
	// wiat for capture thread exit
	m_bCapture = FALSE;
	
	while (m_hCapture)
	{
		usleep(10*1000);
	}

	// stop graph builder
	if (m_pMediaControl)
	{
		m_pMediaControl->Stop();
	}

    m_pGraphBuilder = NULL;
    m_pSampleGrabberFilter = NULL;
    m_pSampleGrabber = NULL;
    m_pMediaEvent = NULL;
    m_pMediaControl = NULL;
    m_pNullRendererFilter = NULL;
    m_pDeviceFilter = NULL;

    if (m_pBuffer)
    {
    	delete[] m_pBuffer;
		m_pBuffer = NULL;
    }

    m_nBuffersize = 0;
    m_bInited = FALSE;
}

void CWVideoCapture::captureThread()
{	
	uint32 curtime;
	uint32 lasttime = sys_os_get_ms();
	double timestep = 1000.0 / m_nFramerate;
		
	while (m_bCapture)
	{
		if (capture())
		{
			curtime = sys_os_get_ms();
			if (curtime - lasttime < timestep)
			{
				usleep(timestep * 1000);
			}
			else
			{
				usleep(10*1000);
			}

			lasttime = curtime;
		}
		else
		{
			usleep(10*1000);
		}
	}

	m_hCapture = 0;
}





