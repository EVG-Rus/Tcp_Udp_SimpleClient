/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef AUDIO_PLAY_WIN_H
#define AUDIO_PLAY_WIN_H

#include <mmsystem.h>
#include "media_format.h"
#include "audio_play.h"

#pragma comment(lib, "winmm.lib")


class CWAudioPlay : public CAudioPlay
{
public:
	CWAudioPlay(int samplerate, int channels);
	~CWAudioPlay();
	
public:
	BOOL        startPlay();
	void        stopPlay();
	int         setVolume(int volume);
	int         getVolume();
	void        playAudio(uint8 * pData, int len);
	
	void        waveOutProc();
	void        onClose();
	
private:
	WAVEHDR   * allocateBlocks(int size, int count);
	void        freeBlocks(WAVEHDR* blockArray);
	

#define BLOCK_SIZE		        320 
#define BLOCK_COUNT		        20

private:
	HWAVEOUT            m_hWaveOut;
	WAVEHDR 		  * m_pWaveBlocks;
	
	CRITICAL_SECTION	m_waveCriticalSection;
	volatile int		m_waveFreeBlockCount;
	int					m_waveCurrentBlock;
};

#endif // AUDIO_PLAY_WIN_H



