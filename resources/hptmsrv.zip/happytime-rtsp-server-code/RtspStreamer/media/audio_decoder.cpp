/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "audio_decoder.h"


CAudioDecoder::CAudioDecoder()
: m_nAudioCodec(AUDIO_CODEC_NONE)
, m_nSamplerate(0)
, m_nChannels(0)
, m_pCallback(NULL)
, m_pUserdata(NULL)
, m_bCodecInited(FALSE)
, m_pCodec(NULL)
, m_pCodecCtx(NULL)
, m_pFrame(NULL)
, m_pSwrCtx(NULL)
{	
}

CAudioDecoder::~CAudioDecoder()
{
	uninit();
}

BOOL CAudioDecoder::init(int codec, int samplerate, int channels, uint8 * extradata, int extradatasize)
{
	if (AUDIO_CODEC_G711A == codec)
	{
		m_pCodec = avcodec_find_decoder(AV_CODEC_ID_PCM_ALAW);
	}
	else if (AUDIO_CODEC_G711U == codec)
	{
		m_pCodec = avcodec_find_decoder(AV_CODEC_ID_PCM_MULAW);		
	}
	else if (AUDIO_CODEC_G726 == codec)
	{
		m_pCodec = avcodec_find_decoder(AV_CODEC_ID_ADPCM_G726);		
	}
	else if (AUDIO_CODEC_AAC == codec)
	{
		m_pCodec = avcodec_find_decoder(AV_CODEC_ID_AAC);	
	}
	else if (AUDIO_CODEC_G722 == codec)
	{
	    m_pCodec = avcodec_find_decoder(AV_CODEC_ID_ADPCM_G722);
	}
	else if (AUDIO_CODEC_OPUS == codec)
	{
	    m_pCodec = avcodec_find_decoder(AV_CODEC_ID_OPUS);
	}
	
	if (m_pCodec == NULL)
	{
		return FALSE;
	}
	
	m_pCodecCtx = avcodec_alloc_context3(m_pCodec);
	if (NULL == m_pCodecCtx)
	{
		return FALSE;
	}

	m_pCodecCtx->sample_rate = samplerate;
	m_pCodecCtx->channels = channels;
	m_pCodecCtx->sample_fmt = AV_SAMPLE_FMT_S16;
	m_pCodecCtx->channel_layout = av_get_default_channel_layout(channels);

	if (AUDIO_CODEC_G726 == codec)
	{
		m_pCodecCtx->bits_per_coded_sample = 32/8;
    	m_pCodecCtx->bit_rate = m_pCodecCtx->bits_per_coded_sample * m_pCodecCtx->sample_rate;
    }
    
    if (extradatasize > 0 && extradata)
    {
    	m_pCodecCtx->extradata = (uint8 *)av_malloc(extradatasize + AV_INPUT_BUFFER_PADDING_SIZE);
	    if (m_pCodecCtx->extradata)
	    {
	        memset(m_pCodecCtx->extradata + extradatasize, 0, AV_INPUT_BUFFER_PADDING_SIZE);
	        memcpy(m_pCodecCtx->extradata, extradata, extradatasize);
	        m_pCodecCtx->extradata_size = extradatasize;
	    } 
    }
    
	if (avcodec_open2(m_pCodecCtx, m_pCodec, NULL) < 0)
	{		
		return FALSE;
	}

	m_pFrame = av_frame_alloc();
	if (NULL == m_pFrame)
	{	
		return FALSE;
	}

	m_nAudioCodec = codec;
	m_nSamplerate = samplerate;
	m_nChannels = channels;
	
	m_bCodecInited = TRUE;
	
	return TRUE;
}

BOOL CAudioDecoder::decode(uint8 * data, int size)
{
	int bytesDecoded = 0;
	int bytesRemaining = size;
	int frameFinished = 0;
	
	if (!m_bCodecInited)
	{
		return FALSE;
	}

	AVPacket packet;
	
	while (bytesRemaining > 0)
	{
		av_init_packet(&packet);
		
		packet.data = data;
		packet.size = bytesRemaining;

		bytesDecoded = avcodec_decode_audio4(m_pCodecCtx, m_pFrame, &frameFinished, &packet);
		if (bytesDecoded < 0)
		{
			log_print(LOG_WARN, "CAudioDecoder::decode, Error while decoding frame\r\n");
			return FALSE;
		}

		if (frameFinished)
		{
			render();			
		}

		bytesRemaining -= bytesDecoded;
		data += bytesDecoded;
	}

	return TRUE;
}

void CAudioDecoder::flush()
{
	if (NULL == m_pCodecCtx || 
		NULL == m_pCodecCtx->codec || 
		!(m_pCodecCtx->codec->capabilities | AV_CODEC_CAP_DELAY))
	{
		return;
	}
	
	int got = 0;
	AVPacket pkt;
	
	av_init_packet(&pkt);
	pkt.data = 0;
	pkt.size = 0;
	
	int ret = avcodec_decode_audio4(m_pCodecCtx, m_pFrame, &got, &pkt);
	while (ret >= 0 && got)
	{
		ret = avcodec_decode_audio4(m_pCodecCtx, m_pFrame, &got, &pkt);
	}
}

void CAudioDecoder::uninit()
{
	flush();
	
	if (m_pCodecCtx)
	{
		avcodec_close(m_pCodecCtx);
		avcodec_free_context(&m_pCodecCtx);		
	}

	if (m_pFrame)
	{
	    av_frame_free(&m_pFrame);
	}	

	if (m_pSwrCtx)
	{
		swr_free(&m_pSwrCtx);
	}

	m_bCodecInited = FALSE;
}

void CAudioDecoder::render()
{
	if (m_pFrame->sample_rate != m_nSamplerate || 
		m_pFrame->channels != m_nChannels || 
		m_pFrame->format != AV_SAMPLE_FMT_S16)
	{
		if (m_pSwrCtx)
		{
			swr_free(&m_pSwrCtx);
		}
		
		m_pSwrCtx = swr_alloc_set_opts(NULL, 
			av_get_default_channel_layout(m_nChannels), AV_SAMPLE_FMT_S16, m_nSamplerate, 
			av_get_default_channel_layout(m_pFrame->channels), (enum AVSampleFormat)m_pFrame->format, m_pFrame->sample_rate, 0, NULL);

		swr_init(m_pSwrCtx);
	}

	if (m_pSwrCtx)
	{
		AVFrame * pResampleFrame = av_frame_alloc();
		
		pResampleFrame->sample_rate = m_nSamplerate;
		pResampleFrame->format = AV_SAMPLE_FMT_S16;
		pResampleFrame->channels = m_nChannels;
		pResampleFrame->channel_layout = av_get_default_channel_layout(m_nChannels);
			
		int swrret = swr_convert_frame(m_pSwrCtx, pResampleFrame, m_pFrame);
		if (swrret == 0)
		{
			if (m_pCallback)
			{
				m_pCallback(pResampleFrame->data[0], pResampleFrame->nb_samples * m_nChannels * 2, m_pUserdata);
			}
		}

		av_frame_free(&pResampleFrame);
	}
	else
	{
		m_pCallback(m_pFrame->data[0], m_pFrame->nb_samples * m_nChannels * 2, m_pUserdata);
	}
	
}



