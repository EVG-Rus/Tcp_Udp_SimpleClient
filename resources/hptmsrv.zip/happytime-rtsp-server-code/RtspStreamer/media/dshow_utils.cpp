/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "dshow_utils.h"
#include <atlbase.h>


HRESULT getPin(IBaseFilter* pFilter, PIN_DIRECTION dirrequired, int iNum, IPin** ppPin)
{
    CComPtr<IEnumPins> pEnumPins;
    *ppPin = NULL;

    HRESULT hr = pFilter->EnumPins(&pEnumPins);
    if (FAILED(hr)) 
    {
        return hr;
    }

    IPin* pPin = NULL;
    hr = E_FAIL;
    PIN_DIRECTION pindir;

    while (S_OK == pEnumPins->Next(1, &pPin, NULL))
    {
        pPin->QueryDirection(&pindir);
        
        if (pindir == dirrequired)
        {
            if (iNum == 0)
            {
                *ppPin = pPin;  // Return the pin's interface
                hr = S_OK;      // Found requested pin, so clear error
                break;
            }
            
            iNum--;
        } 

        pPin->Release();
    } 

    return hr;
}

HRESULT getInPin(IBaseFilter * pFilter, int nPin, IPin** ppPin)
{
    return getPin(pFilter, PINDIR_INPUT, nPin, ppPin);
}

HRESULT getOutPin(IBaseFilter * pFilter, int nPin, IPin** ppPin)
{
	return getPin(pFilter, PINDIR_OUTPUT, nPin, ppPin);
}




