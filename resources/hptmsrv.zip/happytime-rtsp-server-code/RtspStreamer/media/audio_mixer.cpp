/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "audio_mixer.h"


CAudioMixer::CAudioMixer()
    : m_hMixer(NULL)
{
}


CAudioMixer::~CAudioMixer()
{
    if (m_hMixer != 0)
    {
        mixerClose(m_hMixer);
        m_hMixer = NULL;
    }
}


UINT CAudioMixer::GetNumDevs()
{
    return mixerGetNumDevs();
}


BOOL CAudioMixer::GetDevName(UINT nIndex, LPTSTR lpName, int nLen)
{
    MMRESULT  mmr;
	MIXERCAPS mxcaps;

    mmr = mixerGetDevCaps(nIndex, &mxcaps, sizeof(mxcaps));
	if (MMSYSERR_NOERROR == mmr) 
	{
	    lstrcpyn(lpName, mxcaps.szPname, nLen);
	    return TRUE;
	}

	return FALSE;
}


BOOL CAudioMixer::OpenDevice(LPCTSTR lpszDevice) 
{
	MMRESULT  mmr;
	MIXERCAPS mxcaps;

	if (m_hMixer != 0)
    {
        mixerClose(m_hMixer);
        m_hMixer = NULL;
    }

    int nIndex = -1;
	int nums = mixerGetNumDevs();

    if (NULL == lpszDevice || lstrlen(lpszDevice) == 0)
    {
        if (nums > 0)
        {
            nIndex = 0;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        for (int num = 0; num < nums; num++)
    	{
    		mmr = mixerGetDevCaps(num, &mxcaps, sizeof(mxcaps));
    		if (MMSYSERR_NOERROR == mmr) 
    		{
    			if(lstrcmp(mxcaps.szPname, lpszDevice) == 0)
    			{				
    				nIndex = num;
    				break;
    			}
    		}
    	}	
    }
    
	if (nIndex >= 0)
	{
	    mixerOpen(&m_hMixer, nIndex, 0, 0L, 0);
	}

	return (m_hMixer != NULL);
}


DWORD CAudioMixer::ToComponentType(short nComponent)
{
    DWORD dwComp = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
    
    switch(nComponent)
    {
    case UM_MIXER_COMP_WAVE:
        dwComp = MIXERLINE_COMPONENTTYPE_SRC_WAVEOUT;
        break;

    case UM_MIXER_COMP_LINEIN:
        dwComp = MIXERLINE_COMPONENTTYPE_SRC_LINE;
		break;

	case UM_MIXER_COMP_WAVEIN:
		dwComp = MIXERLINE_COMPONENTTYPE_SRC_MICROPHONE; // MIXERLINE_COMPONENTTYPE_DST_WAVEIN;
		break;
    }

    return dwComp;
}


DWORD CAudioMixer::ToControl(short nControl)
{
    DWORD dwCtrl = MIXERCONTROL_CONTROLTYPE_VOLUME;
    
    switch(nControl)
    {
    case UM_MIXER_CTRL_MUTE:
        dwCtrl = MIXERCONTROL_CONTROLTYPE_MUTE;
        break;

	case UM_MIXER_CTRL_ONOFF:
		dwCtrl = MIXERCONTROL_CONTROLTYPE_MUX;
		break;
    }

    return dwCtrl;
}


BOOL CAudioMixer::GetMixerControl(short nComponent, short nControl, DWORD * pdwValue) 
{
	BOOL bRet = FALSE;
	MMRESULT mmr;
	
	if (m_hMixer != 0)
	{
	    MIXERLINE mxl;	    
		mxl.cbStruct = sizeof(mxl);			
		mxl.dwComponentType = ToComponentType(nComponent);			
		
		mmr = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl, MIXER_GETLINEINFOF_COMPONENTTYPE);
		if (MMSYSERR_NOERROR == mmr)
		{
		    MIXERCONTROL mxc;
		    MIXERLINECONTROLS mxlc;

			mxlc.cbStruct = sizeof(mxlc);
			mxlc.cControls = 1;
			mxlc.dwLineID = mxl.dwLineID;
			mxlc.cbmxctrl = sizeof(MIXERCONTROL);
			mxlc.pamxctrl = &mxc;
			mxlc.dwControlID = ToControl(nControl);

			mmr = mixerGetLineControls((HMIXEROBJ)m_hMixer, &mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
			if (MMSYSERR_NOERROR == mmr)
			{
			    MIXERCONTROLDETAILS	mxcd;
	            MIXERCONTROLDETAILS_UNSIGNED mxcd_u;
	
				mxcd.cbStruct		= sizeof(mxcd);
				mxcd.cChannels		= 1; 
				mxcd.dwControlID	= mxc.dwControlID ; 
				mxcd.cMultipleItems = mxc.cMultipleItems;
				mxcd.cbDetails      = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
				mxcd.paDetails      = &mxcd_u; 
				
				mmr = mixerGetControlDetails((HMIXEROBJ)m_hMixer, &mxcd, MIXER_GETCONTROLDETAILSF_VALUE);
				if(MMSYSERR_NOERROR == mmr)
				{
				    if(NULL != pdwValue)
				    {
				        *pdwValue = mxcd_u.dwValue;
				    }
				    
					bRet = TRUE;
				}	
			}
		}
	}	
	
	return bRet;	
}



BOOL CAudioMixer::SetMixerControl(short nComponent, short nControl, DWORD dwValue)
{
    BOOL bRet = FALSE;
	MMRESULT mmr;
	
	if (m_hMixer != 0)
	{
	    MIXERLINE mxl;	    
		mxl.cbStruct = sizeof(mxl);			
		mxl.dwComponentType = ToComponentType(nComponent);			
		
		mmr = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl, MIXER_GETLINEINFOF_COMPONENTTYPE);
		if (MMSYSERR_NOERROR == mmr)
		{
		    MIXERCONTROL mxc;
		    MIXERLINECONTROLS mxlc;

			mxlc.cbStruct = sizeof(mxlc);
			mxlc.cControls = 1;
			mxlc.dwLineID = mxl.dwLineID;
			mxlc.cbmxctrl = sizeof(MIXERCONTROL);
			mxlc.pamxctrl = &mxc;
			mxlc.dwControlID = ToControl(nControl);

			mmr = mixerGetLineControls((HMIXEROBJ)m_hMixer, &mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
			if (MMSYSERR_NOERROR == mmr)
			{
			    MIXERCONTROLDETAILS	mxcd;
	            MIXERCONTROLDETAILS_UNSIGNED mxcd_u;
	
				mxcd.cbStruct		= sizeof(mxcd);
				mxcd.cChannels		= 1; 
				mxcd.dwControlID	= mxc.dwControlID ; 
				mxcd.cMultipleItems = mxc.cMultipleItems;
				mxcd.cbDetails      = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
				mxcd.paDetails      = &mxcd_u; 
				mxcd_u.dwValue      = dwValue;
				
				mmr = mixerSetControlDetails((HMIXEROBJ)m_hMixer, &mxcd, MIXER_SETCONTROLDETAILSF_VALUE);
				if(MMSYSERR_NOERROR == mmr)
				{
					bRet = TRUE;
				}	
			}
		}
	}	
	
	return bRet;	
}


BOOL CAudioMixer::GetMasterVolume(DWORD * pdwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return GetMixerControl(UM_MIXER_COMP_MASTER, nControl, pdwValue);
}


BOOL CAudioMixer::GetWaveVolume(DWORD * pdwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return GetMixerControl(UM_MIXER_COMP_WAVE, nControl, pdwValue);
}

BOOL CAudioMixer::GetLineVolume(DWORD * pdwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return GetMixerControl(UM_MIXER_COMP_LINEIN, nControl, pdwValue);
}

BOOL CAudioMixer::SetMasterVolume(DWORD dwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return SetMixerControl(UM_MIXER_COMP_MASTER, nControl, dwValue);
}


BOOL CAudioMixer::SetWaveVolume(DWORD dwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return SetMixerControl(UM_MIXER_COMP_WAVE, nControl, dwValue);
}

BOOL CAudioMixer::SetLineVolume(DWORD dwValue, BOOL bMute)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    if(bMute)
    {
        nControl = UM_MIXER_CTRL_MUTE;
    }
    
    return SetMixerControl(UM_MIXER_COMP_LINEIN, nControl, dwValue);
}

#ifdef UNICODE
int CAudioMixer::GetControlList(DWORD dwComponentType, DWORD dwControlType, vector<wstring> & strNameVec)
#else
int CAudioMixer::GetControlList(DWORD dwComponentType, DWORD dwControlType, vector<string> & strNameVec)
#endif
{
    if (m_hMixer == NULL)
	{
		return -1;
	}

	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = dwComponentType;
	if (::mixerGetLineInfo(reinterpret_cast<HMIXEROBJ>(m_hMixer),
						   &mxl,
						   MIXER_OBJECTF_HMIXER |
						   MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
	{
		return -1;
	}

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = dwControlType;
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls(reinterpret_cast<HMIXEROBJ>(m_hMixer),
							   &mxlc,
							   MIXER_OBJECTF_HMIXER |
							   MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
	{
		return -1;
	}

	if (mxc.cMultipleItems == 0)
	{
		return 0;
	}

	// get the index of the Microphone Select control
	MIXERCONTROLDETAILS_LISTTEXT *pmxcdSelectText =
		new MIXERCONTROLDETAILS_LISTTEXT[mxc.cMultipleItems];

	if (pmxcdSelectText == NULL)
	{
	    return -1;
	}
	
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = mxc.dwControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = mxc.cMultipleItems;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_LISTTEXT);
	mxcd.paDetails = pmxcdSelectText;
	if (::mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
								 &mxcd,
								 MIXER_OBJECTF_HMIXER |
								 MIXER_GETCONTROLDETAILSF_LISTTEXT)
		== MMSYSERR_NOERROR)
	{		
		DWORD dwi;
		for (dwi = 0; dwi < mxc.cMultipleItems; dwi++)
		{
			// get the line information
			MIXERLINE mxl;
			mxl.cbStruct = sizeof(MIXERLINE);
			mxl.dwLineID = pmxcdSelectText[dwi].dwParam1;
			if (::mixerGetLineInfo(reinterpret_cast<HMIXEROBJ>(m_hMixer),
								   &mxl,
								   MIXER_OBJECTF_HMIXER |
								   MIXER_GETLINEINFOF_LINEID)
				== MMSYSERR_NOERROR)
			{
				strNameVec.push_back(pmxcdSelectText[dwi].szName);
			}
		}		
    }
    else if (mxc.cMultipleItems == 1)
    {
#ifdef UNICODE    
        strNameVec.push_back(L"Microphone");
#else
        strNameVec.push_back("Microphone");
#endif
    }
    
	delete []pmxcdSelectText;

	return mxc.cMultipleItems;
}


BOOL CAudioMixer::SetControl(DWORD dwComponentType, DWORD dwControlType, UINT nIndex, BOOL bSelect)
{
    if (m_hMixer == NULL)
	{
		return FALSE;
	}

	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = dwComponentType;
	if (::mixerGetLineInfo(reinterpret_cast<HMIXEROBJ>(m_hMixer),
						   &mxl,
						   MIXER_OBJECTF_HMIXER |
						   MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
	{
		return FALSE;
	}

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = dwControlType;
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls(reinterpret_cast<HMIXEROBJ>(m_hMixer),
							   &mxlc,
							   MIXER_OBJECTF_HMIXER |
							   MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
	{
		return FALSE;
	}

	if (nIndex >= mxc.cMultipleItems)
	{
		return FALSE;
	}

    // get all the values first
	MIXERCONTROLDETAILS_BOOLEAN *pmxcdSelectValue =
		new MIXERCONTROLDETAILS_BOOLEAN[mxc.cMultipleItems];

	if (pmxcdSelectValue == NULL)
	{
	    return FALSE;
	}
	
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = mxc.dwControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = mxc.cMultipleItems;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
	mxcd.paDetails = pmxcdSelectValue;
	if (::mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
								 &mxcd,
								 MIXER_OBJECTF_HMIXER |
								 MIXER_GETCONTROLDETAILSF_VALUE)
		== MMSYSERR_NOERROR)
	{
		// MUX restricts the line selection to one source line at a time.
		if (bSelect != 0 && dwControlType == MIXERCONTROL_CONTROLTYPE_MUX)
		{
			::ZeroMemory(pmxcdSelectValue,
						 mxc.cMultipleItems * sizeof(MIXERCONTROLDETAILS_BOOLEAN));
		}

		// set the Microphone value
		pmxcdSelectValue[nIndex].fValue = bSelect;

		mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
		mxcd.dwControlID = mxc.dwControlID;
		mxcd.cChannels = 1;
		mxcd.cMultipleItems = mxc.cMultipleItems;
		mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
		mxcd.paDetails = pmxcdSelectValue;
		if (::mixerSetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
									 &mxcd,
									 MIXER_OBJECTF_HMIXER |
									 MIXER_SETCONTROLDETAILSF_VALUE)
			!= MMSYSERR_NOERROR)
		{
			return FALSE;
		}
	}

	delete []pmxcdSelectValue;

	return TRUE;
	
}

#ifdef UNICODE
int CAudioMixer::GetRecordSource(vector<wstring> & strNameVec)
#else
int CAudioMixer::GetRecordSource(vector<string> & strNameVec)
#endif
{
    int nNums = GetControlList(MIXERLINE_COMPONENTTYPE_DST_WAVEIN, MIXERCONTROL_CONTROLTYPE_MIXER, strNameVec);
    if (nNums <= 0)
    {
        strNameVec.clear();
        nNums = GetControlList(MIXERLINE_COMPONENTTYPE_DST_WAVEIN, MIXERCONTROL_CONTROLTYPE_MUX, strNameVec);
    }

    return nNums;
}


int CAudioMixer::SetRecordSource(UINT nIndex)
{
    BOOL bRet = SetControl(MIXERLINE_COMPONENTTYPE_DST_WAVEIN, MIXERCONTROL_CONTROLTYPE_MIXER, nIndex, TRUE);
    if (!bRet)
    {
        bRet = SetControl(MIXERLINE_COMPONENTTYPE_DST_WAVEIN, MIXERCONTROL_CONTROLTYPE_MUX, nIndex, TRUE);
    }

    return bRet;
}


BOOL CAudioMixer::GetMicVolumeRange(int & min, int & max)
{
    BOOL bRet = FALSE;
	MMRESULT mmr;
	
	if (m_hMixer != 0)
	{
	    MIXERLINE mxl;	    
		mxl.cbStruct = sizeof(mxl);			
		mxl.dwComponentType = ToComponentType(UM_MIXER_COMP_WAVEIN);			
		
		mmr = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl, MIXER_GETLINEINFOF_COMPONENTTYPE);
		if (MMSYSERR_NOERROR == mmr)
		{
		    MIXERCONTROL mxc;
		    MIXERLINECONTROLS mxlc;

			mxlc.cbStruct = sizeof(mxlc);
			mxlc.cControls = 1;
			mxlc.dwLineID = mxl.dwLineID;
			mxlc.cbmxctrl = sizeof(MIXERCONTROL);
			mxlc.pamxctrl = &mxc;
			mxlc.dwControlID = ToControl(0);

			mmr = mixerGetLineControls((HMIXEROBJ)m_hMixer, &mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
			if (MMSYSERR_NOERROR == mmr)
			{
			    min = mxc.Bounds.lMinimum;
			    max = mxc.Bounds.lMaximum;
			    
			    bRet = true;
			}
		}
	}	
	
	return bRet;	
}


BOOL CAudioMixer::GetMicVolume(DWORD & volume)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    
    return GetMixerControl(UM_MIXER_COMP_WAVEIN, nControl, &volume);
}


BOOL CAudioMixer::SetMicVolume(DWORD volume)
{
    short nControl = UM_MIXER_CTRL_VOLUME;
    
    return SetMixerControl(UM_MIXER_COMP_WAVEIN, nControl, volume);
}


BOOL CAudioMixer::SetMicAsRecSrc()
{
    BOOL bRet = FALSE;
	MMRESULT mmr;
	
	if (m_hMixer != 0)
	{
	    MIXERLINE mxl;	    
		mxl.cbStruct = sizeof(mxl);			
		mxl.dwComponentType = ToComponentType(UM_MIXER_COMP_WAVEIN);
		
		mmr = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl, MIXER_GETLINEINFOF_COMPONENTTYPE);
		if (MMSYSERR_NOERROR == mmr)
		{
		    MIXERCONTROL mxc;
		    MIXERLINECONTROLS mxlc;

			mxlc.cbStruct = sizeof(mxlc);
			mxlc.cControls = 1;
			mxlc.dwLineID = mxl.dwLineID;
			mxlc.cbmxctrl = sizeof(MIXERCONTROL);
			mxlc.pamxctrl = &mxc;
			mxlc.dwControlID = ToControl(UM_MIXER_CTRL_ONOFF);

			mmr = mixerGetLineControls((HMIXEROBJ)m_hMixer, &mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
			if (MMSYSERR_NOERROR == mmr)
			{
			    MIXERCONTROLDETAILS	mxcd;
	            MIXERCONTROLDETAILS_BOOLEAN mxcd_u;
	
				mxcd.cbStruct		= sizeof(mxcd);
				mxcd.cChannels		= 1; 
				mxcd.dwControlID	= mxc.dwControlID ; 
				mxcd.cMultipleItems = mxc.cMultipleItems;
				mxcd.cbDetails      = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
				mxcd.paDetails      = &mxcd_u; 
				mxcd_u.fValue       = TRUE;
				
				mmr = mixerSetControlDetails((HMIXEROBJ)m_hMixer, &mxcd, MIXER_SETCONTROLDETAILSF_VALUE);
				if (MMSYSERR_NOERROR == mmr)
				{
					bRet = TRUE;
				}	
			}
		}
	}	
	
	return bRet;
}




