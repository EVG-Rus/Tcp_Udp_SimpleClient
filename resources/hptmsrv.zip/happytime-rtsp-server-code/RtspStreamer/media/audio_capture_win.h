/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef _AUDIO_CAPTURE_WIN_H
#define _AUDIO_CAPTURE_WIN_H

/***************************************************************************************/

#include <mmsystem.h>
#include "audio_capture.h"

#pragma comment(lib, "winmm.lib")

/***************************************************************************************/

class CWAudioCapture : public CAudioCapture
{
public:
    
    // get audio capture devcie nubmers     
    static int getDeviceNums();

    // get single instance
	static CAudioCapture * getInstance(int devid);

    BOOL    initCapture(int codec, int sampleRate, int channels);
	BOOL    startCapture();
    
    int     setVolume(int volume);
	int     getVolume();

    // called by MicCallback
    void    onClose();
    void    procData(uint8 * data, int size);
    
private:
    CWAudioCapture();
    CWAudioCapture(CWAudioCapture &obj);
	~CWAudioCapture();
	
    void    clear();
    
    // set audio record source
    BOOL    setSource();
    void    stopCapture();    
    
private:
    HWAVEIN		            m_hWaveIn;      // input device	 
    BYTE *			        m_pBuffer1;     // data buffer
    BYTE *			        m_pBuffer2;     // data buffer
    WAVEHDR		            m_wHdr1;
    WAVEHDR		            m_wHdr2;
};


#endif // _AUDIO_CAPTURE_WIN_H


