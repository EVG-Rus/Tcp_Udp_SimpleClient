/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "audio_capture_win.h"
#include "audio_mixer.h"
#include "lock.h"

/***************************************************************************************/

DWORD CALLBACK MicCallback(HWAVEIN hwavein, UINT uMsg, DWORD_PTR dwInstance, DWORD_PTR dwParam1, DWORD_PTR dwParam2)
{
	CWAudioCapture *pAudioIn = (CWAudioCapture*)dwInstance;
	if (pAudioIn == NULL)
	{
		return -1;
    }
    
	switch (uMsg) 
	{
	case WIM_OPEN:
		break;

	case WIM_DATA:
		if (((PWAVEHDR)dwParam1)->dwBytesRecorded > 0)
		{
		    PWAVEHDR pWaveHdr = (PWAVEHDR)dwParam1;

	    	pAudioIn->procData((uint8 *)pWaveHdr->lpData, pWaveHdr->dwBytesRecorded);
		}

		if (pAudioIn->isCapturing())
		{
			waveInAddBuffer(hwavein, (PWAVEHDR) dwParam1, sizeof(WAVEHDR));
		}

		break;

	case WIM_CLOSE:
	    pAudioIn->onClose();
		break;

	default:
		break;
	}
	
	return 0;
}

CWAudioCapture::CWAudioCapture() : CAudioCapture()
{
    m_hWaveIn = NULL;	 
    m_pBuffer1 = NULL;
    m_pBuffer2 = NULL;
	
    memset(&m_wHdr1, 0, sizeof(WAVEHDR));
    memset(&m_wHdr2, 0, sizeof(WAVEHDR));  
}

CWAudioCapture::~CWAudioCapture()
{
    stopCapture();
}

CAudioCapture * CWAudioCapture::getInstance(int devid)
{
	if (devid < 0 || devid >= MAX_AUDIO_DEV_NUMS)
	{
		return NULL;
	}
	
	if (NULL == m_pInstance[devid])
	{
		sys_os_mutex_enter(m_pInstMutex);

		if (NULL == m_pInstance[devid])
		{
			m_pInstance[devid] = new CWAudioCapture;
			if (m_pInstance[devid])
			{
				m_pInstance[devid]->m_nRefCnt++;
				m_pInstance[devid]->m_nDevIndex = devid;
			}
		}
		
		sys_os_mutex_leave(m_pInstMutex);
	}
	else
	{
		sys_os_mutex_enter(m_pInstMutex);
		m_pInstance[devid]->m_nRefCnt++;
		sys_os_mutex_leave(m_pInstMutex);
	}

	return m_pInstance[devid];
}

int CWAudioCapture::getDeviceNums()
{
	return waveInGetNumDevs();
}

BOOL CWAudioCapture::initCapture(int codec, int samplerate, int channels)
{
	CLock lock(m_pMutex);
	
	if (m_bInited)
	{
		return TRUE;
	}
	
	WAVEFORMATEX waveform;    
    memset(&waveform, 0, sizeof(WAVEFORMATEX));
    
	waveform.wFormatTag = WAVE_FORMAT_PCM;  	
	waveform.nSamplesPerSec = samplerate;    	
	waveform.wBitsPerSample = 16;           	
	waveform.nChannels = 2;           	
	waveform.nAvgBytesPerSec = samplerate * 2 * 2;
	waveform.nBlockAlign = 2 * 2;
	waveform.cbSize = 0;
	
	// Use waveInOpen function to start audio capture
	MMRESULT mmr = waveInOpen(&m_hWaveIn, m_nDevIndex, &waveform, (DWORD_PTR)(MicCallback), DWORD_PTR(this), CALLBACK_FUNCTION);
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
    }
    
	DWORD bufsize = 1024 * 2;
	m_pBuffer1 = new BYTE[bufsize];
	if (NULL == m_pBuffer1)
	{
		return FALSE;
	}
	
	m_pBuffer2 = new BYTE[bufsize];
	if (NULL == m_pBuffer2)
	{
		return FALSE;
	}

	m_wHdr1.lpData = (LPSTR)m_pBuffer1;
	m_wHdr1.dwBufferLength = bufsize;
	m_wHdr1.dwBytesRecorded = 0;
	m_wHdr1.dwUser = 0;
	m_wHdr1.dwFlags = 0;
	m_wHdr1.dwLoops = 1;
	m_wHdr1.lpNext = NULL;
	m_wHdr1.reserved = 0;

	mmr = waveInPrepareHeader(m_hWaveIn, &m_wHdr1, sizeof(WAVEHDR));
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
	}
	
	m_wHdr2.lpData = (LPSTR)m_pBuffer2;
	m_wHdr2.dwBufferLength = bufsize;
	m_wHdr2.dwBytesRecorded = 0;
	m_wHdr2.dwUser = 0;
	m_wHdr2.dwFlags = 0;
	m_wHdr2.dwLoops = 1;
	m_wHdr2.lpNext = NULL;
	m_wHdr2.reserved = 0;

	mmr = waveInPrepareHeader(m_hWaveIn, &m_wHdr2, sizeof(WAVEHDR));
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
	}
	
	mmr = waveInAddBuffer(m_hWaveIn, &m_wHdr1, sizeof(WAVEHDR));
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
	}
	
	mmr = waveInAddBuffer(m_hWaveIn, &m_wHdr2, sizeof(WAVEHDR));
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
	}

	setSource();

	setVolume(150);
	
	AudioEncoderParam params;
	params.SrcChannels = 2;
	params.SrcSamplefmt = AV_SAMPLE_FMT_S16;
	params.SrcSamplerate = samplerate;
	params.DstChannels = channels;
	params.DstSamplefmt = AV_SAMPLE_FMT_S16;
	params.DstSamplerate = samplerate;
	params.DstCodec = codec;

	if (m_encoder.init(&params) == FALSE)
	{
		return FALSE;
	}

	m_nSampleRate = samplerate;	
	m_bInited = TRUE;
	
	return TRUE;
}

BOOL CWAudioCapture::startCapture()
{
    CLock lock(m_pMutex);

	if (!m_bInited)
	{
		return FALSE;
	}
	
	if (m_bCapture)
	{
		return TRUE;
	}
	
	// start audio capture
	MMRESULT mmr = waveInStart(m_hWaveIn);
	if (mmr != MMSYSERR_NOERROR)
	{
		return FALSE;
	}
	
	m_bCapture = TRUE;

	return TRUE;
}

void CWAudioCapture::stopCapture(void)
{
	CLock lock(m_pMutex);
	
	if (m_bCapture)
	{
		m_bCapture = FALSE;

		waveInStop(m_hWaveIn);
		waveInClose(m_hWaveIn);
	}
}

void CWAudioCapture::procData(uint8 * data, int size)
{
	m_encoder.encode(data, size);
}

int CWAudioCapture::setVolume(int volume)
{
    if (volume < 0 || volume > 255 || !m_hWaveIn)
    {
        return -1;
    }

    WAVEINCAPS caps;
    
    if (MMSYSERR_NOERROR != waveInGetDevCaps((UINT_PTR)m_hWaveIn, &caps, sizeof(WAVEINCAPS)))
    {
        return -1;
    }

    CAudioMixer mixer;

    if (!mixer.OpenDevice(caps.szPname))
    {
        return -1;
    }

    int min, max;
    
    if (!mixer.GetMicVolumeRange(min, max))
    {
        return -1;
    }
    
    volume = volume * (max - min) / 255;

    if (!mixer.SetMicVolume(volume))
    {
        return -1;
    }
    
    return 0;
}

int CWAudioCapture::getVolume()
{
    if (!m_hWaveIn)
    {
        return 0;
    }

    WAVEINCAPS caps;
    
    if (MMSYSERR_NOERROR != waveInGetDevCaps((UINT_PTR)m_hWaveIn, &caps, sizeof(WAVEINCAPS)))
    {
        return 0;
    }

    CAudioMixer mixer;

    if (!mixer.OpenDevice(caps.szPname))
    {
        return 0;
    }

    int min, max;
    
    if (!mixer.GetMicVolumeRange(min, max))
    {
        return 0;
    }
    
    if (min == max)
    {
        return 0;
    }

    DWORD volume;
    
    if (!mixer.GetMicVolume(volume))
    {
        return 0;
    }

    volume = volume * 255 / (max - min);

    return volume;
}
	
void CWAudioCapture::onClose()
{
    clear();
}

void CWAudioCapture::clear()
{
	if (m_hWaveIn)
	{
    	waveInUnprepareHeader(m_hWaveIn, &m_wHdr1 ,sizeof(WAVEHDR));
		waveInUnprepareHeader(m_hWaveIn, &m_wHdr2 ,sizeof(WAVEHDR));
	}
	
	m_hWaveIn = NULL;
	
	if (m_pBuffer1)
	{
		delete[] m_pBuffer1;
    }
    
	if (m_pBuffer2)
	{
		delete[] m_pBuffer2;
	}
	
	m_pBuffer1 = NULL;
	m_pBuffer2 = NULL;

	m_bInited = FALSE;
}

BOOL CWAudioCapture::setSource()
{
    WAVEINCAPS caps;
    
    if (MMSYSERR_NOERROR != waveInGetDevCaps((UINT_PTR)m_hWaveIn, &caps, sizeof(WAVEINCAPS)))
    {
        return FALSE;
    }

    CAudioMixer mixer;

    if (!mixer.OpenDevice(caps.szPname))
    {
        return FALSE;
    }

    return mixer.SetMicAsRecSrc();
}



