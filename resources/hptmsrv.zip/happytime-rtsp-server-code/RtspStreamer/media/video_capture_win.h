/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2014-2019, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef _VIDIO_CAPTURE_WIN_H
#define _VIDIO_CAPTURE_WIN_H

#include <atlbase.h>
#include <dshow.h>
#include <qedit.h>
#include "video_capture.h"

/***************************************************************************************/

class CWVideoCapture : public CVideoCapture
{
public:
    // get video capture devices numbers
    static int getDeviceNums();

    // get the single instance
	static CVideoCapture * getInstance(int devid);

	BOOL    initCapture(int codec, int width, int height, int framerate);
	BOOL    startCapture();

    void    captureThread();
    
private:
    CWVideoCapture();
    CWVideoCapture(CWVideoCapture &obj);
	~CWVideoCapture();

    BOOL    capture();
	void    stopCapture();	

	// get device base filter
    BOOL    getDeviceFilter(int nCamID, IBaseFilter **pFilter);
    // connnect filters
    BOOL    connectFilters();
    void    freeMediaType(AM_MEDIA_TYPE * p_mt);
    BOOL    checkMediaType();
    
private:
    
    CComPtr<IGraphBuilder>  m_pGraphBuilder;
    CComPtr<IBaseFilter>    m_pSampleGrabberFilter;
    CComPtr<ISampleGrabber> m_pSampleGrabber;
    CComPtr<IMediaEvent>    m_pMediaEvent;
    CComPtr<IMediaControl>  m_pMediaControl;
    CComPtr<IBaseFilter>    m_pNullRendererFilter;
    CComPtr<IBaseFilter>    m_pDeviceFilter;

	int				        m_nBuffersize;
	uint8 *                 m_pBuffer;
};

#endif // _VIDIO_CAPTURE_WIN_H


