
#pragma once

#include <ws2tcpip.h>
#include <ws2ipdef.h>
#include <winsock2.h>
#include <mmsystem.h>

#include <io.h>
#include <iphlpapi.h>
#include <vfw.h>

#include <tchar.h>



